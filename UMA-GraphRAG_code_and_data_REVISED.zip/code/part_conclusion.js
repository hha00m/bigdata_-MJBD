const H = require("./docx_helpers.js");
const { Paragraph, AlignmentType, FONT, bodyRun, P, H1, H2 } = H;

const h6 = H1("Conclusion", 6);
const s6_p1 = P([bodyRun(
  "We set out to build a decentralized, uncertainty-guided multi-agent GraphRAG framework for temporal legal corpora, and to test the specific claim that uncertainty-weighted pruning and re-ranking would let such a system scale toward trillion-edge corpora. We built UMA-GraphRAG, a working framework with a self-assessed per-agent uncertainty mechanism, a precision-weighted fusion protocol communicating over a sparse topology, and an explicit temporal-validity gate, and evaluated it — alongside a real tuned centralized HNSW-ANN baseline added in this revision — on a synthetic temporal legal citation benchmark we generated and executed ourselves at scales up to 1,000,000 documents and 6,006,226 edges. Two findings are unambiguous. First, the temporal-validity mechanism is worthwhile and degrades gracefully rather than catastrophically under imperfect metadata: a validity-blind baseline returns law that is no longer good law in 30.6% of its top-10 results, every validity-aware method structurally cannot make that mistake, and even substantial metadata corruption only measurably affects recall, not precision, in an interpretable and bounded way (Section 5.2). Second, and less comfortably, a standard tuned centralized ANN index dominates our proposed decentralized protocol on both accuracy and efficiency at every scale we tested — the honest motivation for a decentralized architecture at all has to rest on necessity (data that cannot be centralized, fault tolerance, or scale beyond a single machine's capacity, none of which we tested) rather than on performance (Section 5.7)."
)]);
const s6_p2 = P([bodyRun(
  "Within the decentralized family specifically, the uncertainty-weighted fusion mechanism that gives the method its name is real: an adequately-powered eight-seed comparison shows it beats uniform-weighted fusion with a large effect size (Cohen's d = 1.18, p = 0.0074), self-assessed uncertainty correlates strongly with realized error (Spearman ρ = 0.69-0.86), and a dedicated ablation rules out double-counting of relayed observations as an alternative explanation for the mechanism's behavior. But its advantage is regime-dependent — present at moderate agent-reliability heterogeneity, negligible when agents are uniformly reliable, and reversed under extreme unreliability — and the protocol as specified has a genuine limitation the original submission did not state clearly: its final cross-agent aggregation step is a centralized reduction, not a further decentralized exchange, and additional communication rounds measurably hurt recall in this benchmark rather than helping."
)]);
const s6_p3 = P([bodyRun(
  "We report all of this directly, including the parts that do not favor the proposed method and the ways in which an earlier version of this study understated its own limitations, because we think an accurate account of when and why a mechanism helps — and when a much simpler centralized alternative helps more — is more valuable to the field than a paper that only reports favorable configurations or comparisons against a weak baseline."
)]);

const h6a = H2("Limitations", "6.1");
const limItems = [
  "All experiments use a synthetic benchmark with a controlled generative process, not a real legal citation corpus; absolute recall and validity-precision numbers should not be read as estimates of performance on real case law, though the relative comparisons between methods, run under identical conditions, are more likely to transfer. We did not have access to a licensed real-world citator dataset or a case-law corpus with verified supersession history at the scale this study requires.",
  "A tuned centralized HNSW-ANN index dominates every decentralized method we evaluate at every scale tested (up to 1,000,000 documents, single CPU core) — see Section 5.1 and 5.7. We did not test any corpus size that exceeds a single machine's practical indexing capacity, so this paper does not provide evidence that decentralization becomes necessary, only architectural reasoning about when it plausibly would; testing that regime would require either a genuinely trillion-edge corpus or an explicit memory/throughput constraint that forces sharding, neither of which we had the infrastructure to construct.",
  "The decentralized protocol's communication rounds are evaluated by sequential single-core simulation, and its final cross-agent aggregation step (Algorithm 1, line 22) is a global reduction rather than a further peer-to-peer exchange (Section 3.4) — the protocol is only partially decentralized as specified and evaluated. Work-unit counts are a principled proxy for compute cost under real parallelism, but our wall-clock latency measurements for UMA-GraphRAG and MultiAgentUniform reflect Python-level orchestration overhead specific to this reference implementation and should not be read as deployment latency estimates; HNSW-ANN's latency, measured from the production hnswlib implementation, does not share this caveat.",
  "Agent reliability is modeled as a fixed, known-to-the-agent noise level drawn from a two-tier distribution; real index staleness or compression error may be neither stationary, known, nor well-approximated by additive Gaussian noise.",
  "The coarse practice-area pruning index assumes every document carries a reliable, fixed-taxonomy category label; real legal corpora vary in how consistently such labels are assigned and maintained across jurisdictions and time.",
  "Supersession is modeled as a single pointer per document (overruled or not); Section 5.2's metadata-noise ablation shows the resulting gate degrades gracefully under missing or false-positive records, but the model still collapses amendment, partial overruling, negative treatment, and jurisdictional hierarchy into one binary relation, which recent work shows real citator treatment classification requires distinguishing explicitly [24].",
  "The main comparison (Section 5.1) uses eight independently generated corpus/sharding seeds, which is enough to establish statistical significance for the effect it tests, but the scaling study and the single-topology ablations (heterogeneity, rounds, provenance, calibration, metadata noise) use one fixed corpus and sharding realization each; we do not have multi-seed variance estimates for those trends, so the confidence we can place in them individually is lower than in the main comparison, and we did not have the compute budget in this revision to extend all of them to multiple seeds.",
  "The self-assessed uncertainty mechanism's failure at extreme heterogeneity (Section 5.4) is diagnosed but not fixed in this paper; good aggregate calibration (Section 5.6) does not guarantee the estimator remains reliable in every operating regime the fusion rule might encounter.",
  "We evaluate retrieval quality only (recall, validity precision); we do not evaluate whether retrieved documents actually improve downstream answer correctness in a generation pipeline, which would require either human legal expert review or an LLM-judge protocol validated against one, neither of which we had access to for this study.",
];
const limParas = limItems.map((t) => new Paragraph({
  numbering: { reference: "lim-list", level: 0 },
  spacing: { after: 120, line: 276 },
  alignment: AlignmentType.JUSTIFIED,
  children: [bodyRun(t)],
}));

const h6b = H2("Future Work", "6.2");
const futItems = [
  "A corpus-size-aware pruning schedule, in which the coarse cluster budget C shrinks as N grows rather than staying fixed, is the most direct path toward the sub-linear scaling the trillion-edge motivation requires, and is directly testable within the benchmark harness released with this paper.",
  "A convergence-adaptive round budget — stopping gossip once the marginal candidate discovered per round falls below a threshold, rather than running a fixed R — follows directly from Section 5.5's finding that fixed extra rounds hurt more than they help, and from the provenance-aware ablation's confirmation that this is not simply a double-counting artifact.",
  "Evaluating against a real legal citation corpus with documented, multi-label treatment history — building on CLERC's real case-law retrieval corpus [12] and Demir and Canbaz's fine-grained precedent-treatment taxonomy [24] rather than our single supersession pointer — would test whether the relative method comparisons observed here transfer beyond our synthetic generator, and is the single highest-priority extension of this work.",
  "A genuinely distributed implementation — agents as separate processes or machines, with compiled inner loops rather than a sequential Python simulation — is necessary before any wall-clock latency or throughput claim can be made about the decentralized protocol itself, following the same standard AuthorityBench and comparable systems papers hold centralized RAG baselines to.",
  "A calibration mechanism for self-assessed uncertainty that remains reliable at high agent-noise levels could resolve the reversal identified in Section 5.4, potentially by having agents validate their own ensemble disagreement against a small held-out set of known-good local retrievals rather than relying on the noise-scale proxy alone.",
  "Multi-seed replication of the scaling study and every single-topology ablation, and evaluation at shard counts beyond K = 250, would give a more complete and statistically defensible picture of whether the recall degradation trend of Section 5.3 continues, plateaus, or worsens as a deployment approaches the shard counts a trillion-edge corpus would require.",
  "Testing whether the temporal-validity gate's benefit and the uncertainty-weighted fusion mechanism's benefit are additive, redundant, or interacting when combined with a tuned ANN index rather than brute-force or coarse-pruned local search — since Section 5.7 argues the validity mechanism is architecturally orthogonal to the centralization question, this is directly testable by attaching the same gate to HNSW-ANN.",
  "An end-task evaluation connecting retrieval quality to downstream answer correctness, ideally validated against human legal-expert review rather than automated judging alone, given the responsible-use considerations in the declarations below.",
];
const futParas = futItems.map((t) => new Paragraph({
  numbering: { reference: "fut-list", level: 0 },
  spacing: { after: 120, line: 276 },
  alignment: AlignmentType.JUSTIFIED,
  children: [bodyRun(t)],
}));

// ======================= DECLARATIONS =======================
const h6c = H2("Data and Code Availability", "6.3");
const s6c = P([bodyRun(
  "The synthetic graph generator, the full UMA-GraphRAG and baseline implementation, every experiment driver script, the exact CSV output of every run reported in this paper, and the figure-generation scripts are provided as a supplementary archive accompanying this manuscript. We have not yet deposited this archive with a persistent DOI-bearing repository (e.g., Zenodo) or a public version-controlled host; doing so, with a tagged release matching this manuscript's results, is an outstanding item we flag rather than omit silently, and we commit to completing it before or upon acceptance at any venue this manuscript is submitted to."
)]);

const h6d = H2("Declarations", "6.4");
const s6d1 = P([
  bodyRun("Conflicts of interest: ", { bold: true }),
  bodyRun("The author declares no financial or non-financial conflicts of interest related to this work."),
]);
const s6d2 = P([
  bodyRun("Funding: ", { bold: true }),
  bodyRun("This research received no external funding and was not supported by any grant."),
]);
const s6d3 = P([
  bodyRun("Author contributions: ", { bold: true }),
  bodyRun("H.A. is the sole author and is responsible for conceptualization, methodology, software, formal analysis, investigation, writing, and review."),
]);
const s6d4 = P([
  bodyRun("Responsible use statement: ", { bold: true }),
  bodyRun("UMA-GraphRAG and the temporal-validity mechanism described in this paper are research prototypes evaluated exclusively on synthetic data. They are not validated for, and must not be used as, a substitute for professional citator services (e.g., Shepard's, KeyCite) or for independent legal review by a qualified attorney before any retrieved authority is relied upon in practice. The validity gate reduces but, as Section 5.2 shows, does not eliminate the risk of omitting or misclassifying controlling authority under imperfect metadata; any deployment on real legal data should be accompanied by human oversight proportionate to the stakes of the decision the retrieval output informs, and should be scoped to a specific, disclosed jurisdiction and body of law rather than assumed to generalize across legal systems, which this study does not test."),
]);

// ======================= REFERENCES =======================
const refsHeading = H1("References");
const refList = [
  "P. Lewis et al., \"Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks,\" in Advances in Neural Information Processing Systems (NeurIPS), vol. 33, 2020, pp. 9459-9474.",
  "V. Karpukhin et al., \"Dense Passage Retrieval for Open-Domain Question Answering,\" in Proc. Conf. Empirical Methods in Natural Language Processing (EMNLP), 2020.",
  "D. Edge, H. Trinh, N. Cheng, J. Bradley, A. Chao, A. Mody, S. Truitt, D. Metropolitansky, R. O. Ness, and J. Larson, \"From Local to Global: A Graph RAG Approach to Query-Focused Summarization,\" arXiv:2404.16130, 2024.",
  "B. J. Gutiérrez, Y. Shu, Y. Gu, M. Yasunaga, and Y. Su, \"HippoRAG: Neurobiologically Inspired Long-Term Memory for Large Language Models,\" in Advances in Neural Information Processing Systems (NeurIPS), 2024. arXiv:2405.14831.",
  "Z. Guo, L. Xia, Y. Yu, T. Ao, and C. Huang, \"LightRAG: Simple and Fast Retrieval-Augmented Generation,\" arXiv:2410.05779, 2024.",
  "X. He, Y. Tian, Y. Sun, N. Chawla, T. Laurent, Y. LeCun, X. Bresson, and B. Hooi, \"G-Retriever: Retrieval-Augmented Generation for Textual Graph Understanding and Question Answering,\" in Advances in Neural Information Processing Systems (NeurIPS), vol. 37, 2024, pp. 132876-132907.",
  "J. Sun, C. Xu, L. Tang, S. Wang, C. Lin, Y. Gong, L. M. Ni, H.-Y. Shum, and J. Guo, \"Think-on-Graph: Deep and Responsible Reasoning of Large Language Model on Knowledge Graph,\" arXiv:2307.07697, 2023.",
  "I. Chalkidis, M. Fergadiotis, P. Malakasiotis, N. Aletras, and I. Androutsopoulos, \"LEGAL-BERT: The Muppets Straight Out of Law School,\" in Findings of the Association for Computational Linguistics: EMNLP 2020, pp. 2898-2904.",
  "I. Chalkidis, A. Jana, D. Hartung, M. Bommarito, I. Androutsopoulos, D. M. Katz, and N. Aletras, \"LexGLUE: A Benchmark Dataset for Legal Language Understanding in English,\" in Proc. 60th Annual Meeting of the Association for Computational Linguistics (ACL), 2022, pp. 4310-4330.",
  "L. Zheng, N. Guha, B. R. Anderson, P. Henderson, and D. E. Ho, \"When Does Pretraining Help? Assessing Self-Supervised Learning for Law and the CaseHOLD Dataset,\" in Proc. 18th Int. Conf. Artificial Intelligence and Law (ICAIL), 2021.",
  "N. Guha, J. Nyarko, D. E. Ho, C. Ré, A. Chilton, et al., \"LegalBench: A Collaboratively Built Benchmark for Measuring Legal Reasoning in Large Language Models,\" in Advances in Neural Information Processing Systems (NeurIPS), Datasets and Benchmarks Track, vol. 36, 2023, pp. 44123-44279.",
  "A. B. Hou, O. Weller, G. Qin, E. Yang, D. Lawrie, N. Holzenberger, A. Blair-Stanek, and B. Van Durme, \"CLERC: A Dataset for Legal Case Retrieval and Retrieval-Augmented Analysis Generation,\" arXiv:2406.17186, 2024.",
  "Q. Wu et al., \"AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation,\" arXiv:2308.08155, 2023.",
  "J. S. Park, J. O'Brien, C. J. Cai, M. R. Morris, P. Liang, and M. S. Bernstein, \"Generative Agents: Interactive Simulacra of Human Behavior,\" in Proc. ACM Symposium on User Interface Software and Technology (UIST), 2023.",
  "Y. Gal and Z. Ghahramani, \"Dropout as a Bayesian Approximation: Representing Model Uncertainty in Deep Learning,\" in Proc. Int. Conf. Machine Learning (ICML), 2016.",
  "B. Lakshminarayanan, A. Pritzel, and C. Blundell, \"Simple and Scalable Predictive Uncertainty Estimation Using Deep Ensembles,\" in Advances in Neural Information Processing Systems (NeurIPS), vol. 30, 2017.",
  "L. Kuhn, Y. Gal, and S. Farquhar, \"Semantic Uncertainty: Linguistic Invariances for Uncertainty Estimation in Natural Language Generation,\" in Proc. Int. Conf. Learning Representations (ICLR), 2023.",
  "A. Demers, D. Greene, C. Hauser, W. Irish, J. Larson, S. Shenker, H. Sturgis, D. Swinehart, and D. Terry, \"Epidemic Algorithms for Replicated Database Maintenance,\" in Proc. ACM Symposium on Principles of Distributed Computing (PODC), 1987, pp. 1-12.",
  "D. J. Watts and S. H. Strogatz, \"Collective Dynamics of 'Small-World' Networks,\" Nature, vol. 393, pp. 440-442, 1998.",
  "B. McMahan, E. Moore, D. Ramage, S. Hampson, and B. A. y Arcas, \"Communication-Efficient Learning of Deep Networks from Decentralized Data,\" in Proc. Int. Conf. Artificial Intelligence and Statistics (AISTATS), 2017.",
  "T. Li, A. K. Sahu, M. Zaheer, M. Sanjabi, A. Talwalkar, and V. Smith, \"Federated Optimization in Heterogeneous Networks,\" in Proc. Machine Learning and Systems (MLSys), 2020.",
  "Y. A. Malkov and D. A. Yashunin, \"Efficient and Robust Approximate Nearest Neighbor Search Using Hierarchical Navigable Small World Graphs,\" IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 42, no. 4, pp. 824-836, 2020.",
  "J. Johnson, M. Douze, and H. Jégou, \"Billion-Scale Similarity Search with GPUs,\" IEEE Trans. Big Data, vol. 7, no. 3, pp. 535-547, 2021.",
  "M. M. Demir and M. A. Canbaz, \"Validate Your Authority: Benchmarking LLMs on Multi-Label Precedent Treatment Classification,\" in Proc. Natural Legal Language Processing Workshop (NLLP), 2025.",
  "A. R. Putta, J. Devasier, and C. Li, \"CaseFacts: A Benchmark for Legal Fact-Checking and Precedent Retrieval,\" arXiv:2601.17230, 2026.",
  "M. Prior, A. Schultz, and M. Grabmair, \"Asking For An Old Friend: Diagnosing and Mitigating Temporal Failure Modes in LLM-based Statutory Question Answering,\" arXiv:2605.23497, 2026.",
  "Z. Yao, H. Zhang, and K. Bi, \"AuthorityBench: Benchmarking LLM Authority Perception for Reliable Retrieval-Augmented Generation,\" arXiv:2603.25092, 2026.",
];
const refParas = refList.map((t, i) => new Paragraph({
  spacing: { after: 120, line: 264 },
  alignment: AlignmentType.JUSTIFIED,
  indent: { left: 360, hanging: 360 },
  children: [bodyRun(`[${i + 1}] ${t}`, { size: 20 })],
}));

module.exports = {
  h6, s6_p1, s6_p2, s6_p3, h6a, limParas, h6b, futParas,
  h6c, s6c, h6d, s6d1, s6d2, s6d3, s6d4,
  refsHeading, refParas,
};
