import csv
import time
import numpy as np
from graph_gen import generate_temporal_legal_graph
from framework import build_hnsw_index, run_query_hnsw, oracle_topk, recall_at_k

OUT = "/home/claude/uma_graphrag/data"


def make_queries(graph, n_q, seed, frac_lo=0.4):
    rng = np.random.default_rng(seed)
    n_nodes = len(graph["timestamps"])
    n_topics = graph["topic_centers"].shape[0]
    dim = graph["embeddings"].shape[1]
    queries = []
    for _ in range(n_q):
        t_topic = rng.integers(0, n_topics)
        qv = graph["topic_centers"][t_topic] + rng.normal(scale=0.3, size=dim)
        qv = qv / np.linalg.norm(qv)
        qt = rng.integers(int(frac_lo * n_nodes), n_nodes)
        queries.append((qv.astype(np.float32), int(qt)))
    return queries


def main():
    scales = [20000, 100000, 400000, 1000000]
    n_q_by_scale = {20000: 40, 100000: 40, 400000: 40, 1000000: 30}
    rows = []
    for n in scales:
        g = generate_temporal_legal_graph(n, seed=1)
        all_ids = np.arange(n)
        t0 = time.time()
        idx = build_hnsw_index(g, ef_construction=200, M=16, ef_search=80)
        build_time = time.time() - t0
        queries = make_queries(g, n_q_by_scale[n], seed=2024)
        recalls, lats = [], []
        for qv, qt in queries:
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)
            t0 = time.perf_counter()
            r = run_query_hnsw(g, idx, qv, qt, k=10, fetch=200)
            lats.append(time.perf_counter() - t0)
            recalls.append(recall_at_k(r["top_ids"], oracle))
        rows.append(dict(n_nodes=n, method="hnsw", recall=np.nanmean(recalls), work=200,
                          latency_ms=np.mean(lats) * 1000, build_time_s=build_time))
        print(f"N={n}  build={build_time:.1f}s  recall={np.nanmean(recalls):.4f}  lat={np.mean(lats)*1000:.3f}ms")

    with open(f"{OUT}/hnsw_scaling.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    main()
