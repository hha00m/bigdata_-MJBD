import csv
import numpy as np
from graph_gen import generate_temporal_legal_graph
from framework import (
    partition_agents, comm_graph, agent_reliability,
    run_query_uma, run_query_uma_provenance, run_query_multiagent_uniform,
    oracle_topk, recall_at_k,
)

OUT = "/home/claude/uma_graphrag/data"


def main():
    n = 100000
    K = max(8, round(n / 4000))
    g = generate_temporal_legal_graph(n, seed=1)
    all_ids = np.arange(n)
    shards = partition_agents(n, K, replication=3, seed=1)
    cg = comm_graph(K, degree=5, seed=1)
    sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=1)

    rng = np.random.default_rng(555)
    n_q = 100
    queries = []
    for _ in range(n_q):
        t_topic = rng.integers(0, g["topic_centers"].shape[0])
        qv = g["topic_centers"][t_topic] + rng.normal(scale=0.3, size=g["embeddings"].shape[1])
        qv = qv / np.linalg.norm(qv)
        qt = int(rng.integers(int(0.4 * n), n))
        queries.append((qv.astype(np.float32), qt))

    rows = []
    for rounds in [0, 1, 2, 3, 4, 5]:
        uma_r, prov_r, uni_r = [], [], []
        msgs_uma, msgs_prov = [], []
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)
            r1 = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=rounds, pool_cap=25, local_m=15)
            r2 = run_query_uma_provenance(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=rounds, pool_cap=25, local_m=15)
            r3 = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=rounds, pool_cap=25, local_m=15)
            uma_r.append(recall_at_k(r1["top_ids"], oracle))
            prov_r.append(recall_at_k(r2["top_ids"], oracle))
            uni_r.append(recall_at_k(r3["top_ids"], oracle))
            msgs_uma.append(r1["msgs"]); msgs_prov.append(r2["msgs"])
        rows.append(dict(
            rounds=rounds,
            uma_recall=np.nanmean(uma_r),
            uma_provenance_recall=np.nanmean(prov_r),
            uniform_recall=np.nanmean(uni_r),
            avg_msgs_uma=np.mean(msgs_uma),
            avg_msgs_provenance=np.mean(msgs_prov),
        ))
        print(f"rounds={rounds}  uma={np.nanmean(uma_r):.4f}  uma_provenance={np.nanmean(prov_r):.4f}  uniform={np.nanmean(uni_r):.4f}")

    with open(f"{OUT}/provenance_ablation.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    main()
