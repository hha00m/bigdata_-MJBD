// build_paper.js -- assembles the UMA-GraphRAG manuscript as a .docx
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  ImageRun, PageBreak, Header, Footer, PageNumber, LevelFormat,
  VerticalAlign, TabStopType, TabStopPosition,
} = require("docx");

const FIG = "/home/claude/uma_graphrag/figures";
const sizeOf = (p) => {
  // minimal PNG size reader (avoids extra deps)
  const buf = fs.readFileSync(p);
  const w = buf.readUInt32BE(16);
  const h = buf.readUInt32BE(20);
  return { w, h };
};
const imgInches = (file, widthIn) => {
  const { w, h } = sizeOf(`${FIG}/${file}`);
  return { width: widthIn, height: widthIn * (h / w) };
};

// ---------- shared style helpers ----------
const FONT = "Times New Roman";
const bodyRun = (text, opts = {}) => new TextRun({ text, font: FONT, size: 22, ...opts });
const P = (children, opts = {}) => new Paragraph({
  children: Array.isArray(children) ? children : [bodyRun(children)],
  spacing: { after: 160, line: 276 },
  alignment: AlignmentType.JUSTIFIED,
  ...opts,
});
const H1 = (text, num) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 320, after: 160 },
  children: [new TextRun({ text: (num ? `${num}. ` : "") + text, bold: true, size: 26, font: FONT })],
});
const H2 = (text, num) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  spacing: { before: 240, after: 120 },
  children: [new TextRun({ text: num ? `${num} ${text}` : text, bold: true, italics: false, size: 23, font: FONT })],
});
const Caption = (text) => new Paragraph({
  spacing: { before: 80, after: 200 },
  alignment: AlignmentType.CENTER,
  children: [new TextRun({ text, italics: true, size: 20, font: FONT })],
});
const CenterImg = (file, widthIn, spacingAfter = 40) => {
  const { width, height } = imgInches(file, widthIn);
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 160, after: spacingAfter },
    children: [new ImageRun({ data: fs.readFileSync(`${FIG}/${file}`), transformation: { width: width * 96, height: height * 96 }, type: "png" })],
  });
};
const EqRow = (file, num, heightIn = 0.34) => {
  const { w, h } = sizeOf(`${FIG}/${file}`);
  const maxWidthIn = 5.7; // leave room for the (N) label within a 6.5in text area
  let widthIn = heightIn * (w / h);
  let useHeightIn = heightIn;
  if (widthIn > maxWidthIn) {
    widthIn = maxWidthIn;
    useHeightIn = widthIn * (h / w);
  }
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
    spacing: { before: 140, after: 140 },
    children: [
      new ImageRun({ data: fs.readFileSync(`${FIG}/${file}`), transformation: { width: widthIn * 96, height: useHeightIn * 96 }, type: "png" }),
      new TextRun({ text: `\t(${num})`, font: FONT, size: 22 }),
    ],
  });
};
const cellText = (text, opts = {}) => new Paragraph({ alignment: opts.align || AlignmentType.CENTER, spacing: { before: 40, after: 40 }, children: [new TextRun({ text, font: FONT, size: 19, bold: !!opts.bold })] });
const TCell = (text, opts = {}) => new TableCell({
  width: opts.width ? { size: opts.width, type: WidthType.DXA } : undefined,
  shading: opts.shade ? { type: ShadingType.CLEAR, fill: "E8EEF7" } : undefined,
  verticalAlign: VerticalAlign.CENTER,
  margins: { top: 60, bottom: 60, left: 100, right: 100 },
  children: [cellText(text, opts)],
});

console.log("helpers loaded");
module.exports = { fs, Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, ImageRun, PageBreak, Header, Footer, PageNumber, LevelFormat, VerticalAlign, TabStopType, TabStopPosition, FIG, sizeOf, imgInches, FONT, bodyRun, P, H1, H2, Caption, CenterImg, EqRow, cellText, TCell };
