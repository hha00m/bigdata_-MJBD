import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

FIG = "/home/claude/uma_graphrag/figures"
plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "cm"})

equations = {
    "eq1": (r"$s_i^{(a)}(q) \,=\, \mathbf{e}_i^{\top}\mathbf{q} \,+\, \varepsilon_i^{(a)}, \qquad "
            r"\varepsilon_i^{(a)} \sim \mathcal{N}\left(0,\, \sigma_a^2\right)$", 1.0),
    "eq2": (r"$u_i^{(a)} \,=\, \mathrm{Var}_{m=1}^{M}\left[\, \mathbf{e}_i^{\top} \mathbf{H}_a^{(m)}\, \mathbf{q} \,\right],"
            r"\quad \mathbf{H}_a^{(m)} = \mathbf{I} + \mathbf{N}^{(m)},\;\; N^{(m)}_{jk} \sim \mathcal{N}(0,\, \tau_a^2)$", 1.0),
    "eq3": (r"$w_i^{(a)} \,=\, \dfrac{1}{\,u_i^{(a)} + \epsilon\,}$", 1.0),
    "eq4a": (r"$s_i^{(a \oplus b)} \,=\, \dfrac{w_i^{(a)} s_i^{(a)} + w_i^{(b)} s_i^{(b)}}{w_i^{(a)} + w_i^{(b)}}$", 1.0),
    "eq4b": (r"$u_i^{(a \oplus b)} \,=\, \dfrac{1}{w_i^{(a)} + w_i^{(b)}}$", 1.0),
    "eq5": (r"$\tau_t \,=\, Q_{1-\rho_t}\left(u^{(a)}\right), \qquad \rho_t \,=\, \max\left(0.3,\; 1 - t/R\right)$", 1.0),
    "eq6": (r"$\mathcal{O}_a^{(t)} \,=\, \left\{\, i \in \mathcal{P}_a^{(t)} \;:\; u_i^{(a)} \leq \tau_t \,\right\}$", 1.0),
    "eq7a": (r"$C(q) \,=\, \left\{\, c \;:\; \mathrm{rank}\left(\boldsymbol{\mu}_c^{\top} \mathbf{q}\right) \leq C^{*} \,\right\}, \qquad "
             r"\Delta = \boldsymbol{\mu}_{(1)}^{\top}\mathbf{q} - \boldsymbol{\mu}_{(2)}^{\top}\mathbf{q}$", 1.0),
    "eq7b": (r"$C^{*} \,=\, 3c_0 \;\;\mathrm{if}\;\; \Delta < 0.05 \; ; \quad 2c_0 \;\;\mathrm{if}\;\; 0.05 \leq \Delta < 0.15 \; ; "
             r"\quad c_0 \;\;\mathrm{otherwise}$", 0.95),
    "eq8": (r"$\mathrm{valid}(i,\, t_q) \,=\, \left[\, t_i < t_q \,\right] \;\wedge\; "
            r"\left(\, \mathrm{sup}(i) = \emptyset \;\vee\; t_{\mathrm{sup}(i)} \geq t_q \,\right)$", 1.0),
}

for name, (tex, scale) in equations.items():
    fig = plt.figure(figsize=(7.4, 0.95))
    fig.text(0.02, 0.5, tex, fontsize=15.5 * scale, ha="left", va="center")
    fig.patch.set_alpha(0)
    fig.savefig(f"{FIG}/{name}.png", dpi=300, transparent=True, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)

print("equations written")
