import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif", "font.size": 10,
    "axes.linewidth": 0.8, "figure.dpi": 300,
    "savefig.bbox": "tight",
})

DATA = "/home/claude/uma_graphrag/data"
FIG = "/home/claude/uma_graphrag/figures"

METHOD_STYLE = {
    "full": dict(color="#1a1a1a", marker="o", ls="-", label="FullGraphRAG (centralized)"),
    "hnsw": dict(color="#2ca02c", marker="P", ls=(0, (1, 1)), label="HNSW-ANN (centralized, tuned)"),
    "static": dict(color="#4c72b0", marker="s", ls="--", label="StaticPruneRAG"),
    "uniform": dict(color="#dd8452", marker="^", ls="-.", label="MultiAgentUniform"),
    "uma": dict(color="#c44e52", marker="D", ls="-", label="UMA-GraphRAG (proposed)"),
}


def read_csv(name):
    with open(f"{DATA}/{name}") as f:
        return list(csv.DictReader(f))


def fig2_scaling():
    rows = read_csv("scaling_results.csv")
    hnsw_rows = read_csv("hnsw_scaling.csv")
    scales = sorted(set(int(r["n_nodes"]) for r in rows))
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.1))

    ax = axes[0]
    for m in ["full", "static", "uniform", "uma"]:
        y = [float([r for r in rows if r["method"] == m and int(r["n_nodes"]) == n][0]["recall"]) for n in scales]
        ax.plot(scales, y, **METHOD_STYLE[m], markersize=5, linewidth=1.3)
    y_hnsw = [float([r for r in hnsw_rows if int(r["n_nodes"]) == n][0]["recall"]) for n in scales]
    ax.plot(scales, y_hnsw, **METHOD_STYLE["hnsw"], markersize=7, linewidth=1.3)
    ax.set_xscale("log")
    ax.set_xlabel("Corpus size $N$ (documents)")
    ax.set_ylabel("Recall@10 vs. oracle")
    ax.set_ylim(0, 1.05)
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.set_title("(a) Retrieval quality vs. scale", fontsize=9.5)

    ax = axes[1]
    for m in ["full", "static", "uniform", "uma"]:
        y = [float([r for r in rows if r["method"] == m and int(r["n_nodes"]) == n][0]["work"]) for n in scales]
        ax.plot(scales, y, **METHOD_STYLE[m], markersize=5, linewidth=1.3)
    y_hnsw = [float([r for r in hnsw_rows if int(r["n_nodes"]) == n][0]["work"]) for n in scales]
    ax.plot(scales, y_hnsw, **METHOD_STYLE["hnsw"], markersize=7, linewidth=1.3)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Corpus size $N$ (documents)")
    ax.set_ylabel("Work units per query")
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.set_title("(b) Per-query compute vs. scale", fontsize=9.5)

    ax = axes[2]
    for m in ["uniform", "uma"]:
        y = [float([r for r in rows if r["method"] == m and int(r["n_nodes"]) == n][0]["msg_bytes"]) for n in scales]
        ax.plot(scales, y, **METHOD_STYLE[m], markersize=5, linewidth=1.3)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Corpus size $N$ (documents)")
    ax.set_ylabel("Bytes exchanged per query")
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.set_title("(c) Communication cost vs. scale", fontsize=9.5)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.1), fontsize=8, frameon=False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig2_scaling.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig3_heterogeneity():
    rows = read_csv("ablation_heterogeneity.csv")
    sh = [float(r["sigma_high"]) for r in rows]
    uma = [float(r["uma_recall"]) for r in rows]
    uni = [float(r["uniform_recall"]) for r in rows]
    gap = [float(r["gap"]) for r in rows]

    fig, ax1 = plt.subplots(figsize=(4.6, 3.4))
    ax1.plot(sh, uma, color="#c44e52", marker="D", ls="-", label="UMA-GraphRAG", markersize=5)
    ax1.plot(sh, uni, color="#dd8452", marker="^", ls="-.", label="MultiAgentUniform", markersize=5)
    ax1.set_xlabel(r"Low-fidelity agent noise level $\sigma_{\mathrm{high}}$")
    ax1.set_ylabel("Recall@10 vs. oracle")
    ax1.grid(alpha=0.25, linewidth=0.5)
    ax1.set_ylim(-0.02, 1.0)

    ax2 = ax1.twinx()
    ax2.bar(sh, gap, width=0.006, color="#55a868", alpha=0.35, label="Recall gap (UMA $-$ Uniform)")
    ax2.axhline(0, color="gray", linewidth=0.6)
    ax2.set_ylabel("Recall gap")
    ax2.set_ylim(-0.15, 0.2)

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, fontsize=7.5, loc="upper right", frameon=False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig3_heterogeneity.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig4_rounds():
    rows = read_csv("ablation_rounds.csv")
    r = [int(x["rounds"]) for x in rows]
    uma = [float(x["uma_recall"]) for x in rows]
    uni = [float(x["uniform_recall"]) for x in rows]
    msgs = [float(x["avg_msgs"]) for x in rows]

    fig, ax1 = plt.subplots(figsize=(4.6, 3.4))
    ax1.plot(r, uma, color="#c44e52", marker="D", ls="-", label="UMA-GraphRAG recall", markersize=5)
    ax1.plot(r, uni, color="#dd8452", marker="^", ls="-.", label="MultiAgentUniform recall", markersize=5)
    ax1.set_xlabel("Communication rounds $R$")
    ax1.set_ylabel("Recall@10 vs. oracle")
    ax1.set_ylim(0, 1.0)
    ax1.grid(alpha=0.25, linewidth=0.5)

    ax2 = ax1.twinx()
    ax2.plot(r, msgs, color="#4c72b0", marker="o", ls=":", label="Messages per query", markersize=4)
    ax2.set_ylabel("Messages exchanged per query")

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, fontsize=7.5, loc="center right", frameon=False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig4_rounds.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig5_main_bars():
    rows = read_csv("main_comparison_expanded.csv")
    methods = ["full", "hnsw", "static", "uniform", "uma", "semantic"]
    labels = ["FullGraphRAG", "HNSW-ANN\n(tuned)", "StaticPruneRAG", "MultiAgentUniform", "UMA-GraphRAG", "SemanticOnly\n(no validity check)"]
    recall_mean, recall_std, vp_mean, vp_std = [], [], [], []
    for m in methods:
        rs = [float(x["recall"]) for x in rows if x["method"] == m]
        vs = [float(x["validity_precision"]) for x in rows if x["method"] == m]
        recall_mean.append(np.mean(rs)); recall_std.append(np.std(rs))
        vp_mean.append(np.mean(vs)); vp_std.append(np.std(vs))

    x = np.arange(len(methods))
    width = 0.36
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    b1 = ax.bar(x - width / 2, recall_mean, width, yerr=recall_std, capsize=3,
                color="#4c72b0", label="Recall@10 vs. oracle", edgecolor="black", linewidth=0.5)
    b2 = ax.bar(x + width / 2, vp_mean, width, yerr=vp_std, capsize=3,
                color="#c44e52", label="Validity precision@10", edgecolor="black", linewidth=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score")
    ax.legend(fontsize=8, frameon=False, loc="upper center", ncol=2)
    ax.grid(alpha=0.2, axis="y", linewidth=0.5)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig5_main_bars.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig2_scaling()
    fig3_heterogeneity()
    fig4_rounds()
    fig5_main_bars()
    print("figures written")
