import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif", "font.size": 10,
    "axes.linewidth": 0.8, "figure.dpi": 300,
    "savefig.bbox": "tight",
})

DATA = "/home/claude/uma_graphrag/data"
FIG = "/home/claude/uma_graphrag/figures"


def read_csv(name):
    with open(f"{DATA}/{name}") as f:
        return list(csv.DictReader(f))


def fig_metadata_noise():
    rows = read_csv("metadata_noise_ablation.csv")
    # Panel A: precision/recall vs p_missing (p_false=0 fixed)
    miss_rows = [r for r in rows if float(r["p_false"]) == 0.0]
    miss_rows.sort(key=lambda r: float(r["p_missing"]))
    # Panel B: precision/recall vs p_false (p_missing=0 fixed)
    false_rows = [r for r in rows if float(r["p_missing"]) == 0.0]
    false_rows.sort(key=lambda r: float(r["p_false"]))

    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    ax = axes[0]
    x = [float(r["p_missing"]) for r in miss_rows]
    prec = [float(r["true_validity_precision"]) for r in miss_rows]
    rec = [float(r["recall_vs_true_oracle"]) for r in miss_rows]
    ax.plot(x, prec, marker="o", color="#c44e52", label="True validity precision", markersize=5)
    ax.plot(x, rec, marker="s", color="#4c72b0", label="Recall vs. true oracle", markersize=5, ls="--")
    ax.set_xlabel(r"$p_{\mathrm{missing}}$ (fraction of true supersessions hidden)")
    ax.set_ylabel("Score")
    ax.set_ylim(0.85, 1.02)
    ax.set_title("(a) Missing supersession records", fontsize=9.5)
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.legend(fontsize=7.5, frameon=False, loc="lower left")

    ax = axes[1]
    x = [float(r["p_false"]) for r in false_rows]
    prec = [float(r["true_validity_precision"]) for r in false_rows]
    rec = [float(r["recall_vs_true_oracle"]) for r in false_rows]
    ax.plot(x, prec, marker="o", color="#c44e52", label="True validity precision", markersize=5)
    ax.plot(x, rec, marker="s", color="#4c72b0", label="Recall vs. true oracle", markersize=5, ls="--")
    ax.set_xlabel(r"$p_{\mathrm{false}}$ (fraction of docs falsely flagged superseded)")
    ax.set_ylabel("Score")
    ax.set_ylim(0.85, 1.02)
    ax.set_title("(b) False-positive supersession flags", fontsize=9.5)
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.legend(fontsize=7.5, frameon=False, loc="lower left")

    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_metadata_noise.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_calibration():
    rows = read_csv("calibration_bins.csv")
    u = [float(r["mean_uncertainty"]) for r in rows]
    rmse = [float(r["rmse"]) for r in rows]

    fig, ax = plt.subplots(figsize=(4.6, 3.4))
    ax.plot(u, rmse, marker="o", color="#55a868", markersize=5)
    ax.set_xlabel("Mean self-assessed uncertainty (bin)")
    ax.set_ylabel("RMSE of local noisy score (bin)")
    ax.set_xscale("log")
    ax.grid(alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_calibration.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig_provenance():
    rows = read_csv("provenance_ablation.csv")
    r = [int(x["rounds"]) for x in rows]
    uma = [float(x["uma_recall"]) for x in rows]
    prov = [float(x["uma_provenance_recall"]) for x in rows]
    uni = [float(x["uniform_recall"]) for x in rows]

    fig, ax = plt.subplots(figsize=(4.6, 3.4))
    ax.plot(r, uma, marker="D", color="#c44e52", label="UMA-GraphRAG (base)", markersize=5)
    ax.plot(r, prov, marker="^", color="#8172b3", label="UMA-GraphRAG (provenance-dedup)", markersize=5, ls="--")
    ax.plot(r, uni, marker="s", color="#dd8452", label="MultiAgentUniform", markersize=5, ls="-.")
    ax.set_xlabel("Communication rounds $R$")
    ax.set_ylabel("Recall@10 vs. oracle")
    ax.set_ylim(0, 1.0)
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.legend(fontsize=7.5, frameon=False, loc="upper right")
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig_provenance.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig_metadata_noise()
    fig_calibration()
    fig_provenance()
    print("revision figures written")
