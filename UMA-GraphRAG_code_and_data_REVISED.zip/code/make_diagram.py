import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib.lines import Line2D

FIG = "/home/claude/uma_graphrag/figures"
plt.rcParams.update({"font.family": "serif", "font.size": 9})

fig, ax = plt.subplots(figsize=(7.2, 5.6))
ax.set_xlim(0, 100)
ax.set_ylim(0, 90)
ax.axis("off")


def box(x, y, w, h, text, fc="#eef2f8", ec="#2f3e5c", fs=8.0, lw=1.1):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.35,rounding_size=1.4",
                        linewidth=lw, edgecolor=ec, facecolor=fc)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color="#1a1a1a")


def arrow(p1, p2, color="#2f3e5c", lw=1.1, connectionstyle="arc3,rad=0.0"):
    a = FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=9, linewidth=lw,
                         color=color, connectionstyle=connectionstyle)
    ax.add_patch(a)


# ---- Row 1: query ------------------------------------------------------
box(4, 80, 22, 8, "Query $q$, time $t_q$", fc="#fdf3e7", ec="#8a5a1e", fs=8.5)

# ---- Row 2: agents (3 shown, "..." for the rest) ------------------------
agent_x = [4, 30, 56]
agent_labels = [
    "Agent 1\nshard $\\mathcal{D}_1$, $\\sigma_1$",
    "Agent 2\nshard $\\mathcal{D}_2$, $\\sigma_2$",
    "Agent $K$\nshard $\\mathcal{D}_K$, $\\sigma_K$",
]
for x, lab in zip(agent_x, agent_labels):
    box(x, 66, 20, 9, lab, fc="#eaf1fb", ec="#2f3e5c", fs=8.3)
    arrow((15, 80), (x + 10, 75), connectionstyle="arc3,rad=0.05")
ax.text(50.5, 70.5, "$\\cdots$", fontsize=15, ha="center", va="center")

# ---- Row 3: per-agent local pipeline (left column, representative of all) --
lx, lw_ = 4, 24
box(lx, 52, lw_, 8, "Coarse topic-cluster pruning\n(Eq. 1-2)", fc="#f5f5f5", ec="#555", fs=7.6)
box(lx, 40, lw_, 8, "Local scoring + temporal\nvalidity filter", fc="#f5f5f5", ec="#555", fs=7.6)
box(lx, 28, lw_, 8, "Self-assessed ensemble\nuncertainty (Eq. 5)", fc="#f5f5f5", ec="#555", fs=7.6)
arrow((lx + 12, 66), (lx + 12, 60), lw=1.0)
arrow((lx + 12, 52), (lx + 12, 48), lw=1.0)
arrow((lx + 12, 40), (lx + 12, 36), lw=1.0)

# ---- Right column: decentralized comm graph -----------------------------
box(50, 52, 46, 9, "Decentralized gossip over sparse agent\ntopology $\\mathcal{G}_{\\mathrm{comm}}$ (Algorithm 1)",
    fc="#fdf3e7", ec="#8a5a1e", fs=7.8)

comm_cx, comm_cy = 73, 34
n_nodes = 7
node_pos = []
for i in range(n_nodes):
    ang = 2 * np.pi * i / n_nodes + np.pi / 2
    node_pos.append((comm_cx + 14 * np.cos(ang), comm_cy + 12 * np.sin(ang)))
edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 0), (0, 3), (2, 5), (1, 5)]
for i, j in edges:
    ax.plot([node_pos[i][0], node_pos[j][0]], [node_pos[i][1], node_pos[j][1]],
            color="#9aa7bd", linewidth=0.9, zorder=1)
for i, (nxp, nyp) in enumerate(node_pos):
    c = Circle((nxp, nyp), 2.5, facecolor="#c44e52" if i == 0 else "#4c72b0",
               edgecolor="black", linewidth=0.6, zorder=2)
    ax.add_patch(c)
    ax.text(nxp, nyp, f"$a_{{{i+1}}}$", ha="center", va="center", fontsize=6.5, color="white", zorder=3)
arrow((50, 56), (lx + lw_ + 2, 44), connectionstyle="arc3,rad=-0.1")
ax.text(comm_cx, comm_cy - 16.5, "each round: forward candidates below the\nuncertainty quantile threshold (Eq. 9-10) to neighbors",
        ha="center", fontsize=7.3, color="#555")

# ---- Row 4: fusion -> aggregation -> output ------------------------------
fy = 4
box(2, fy, 30, 9, "Inverse-uncertainty (precision-\nweighted) fusion (Eq. 6-8)", fc="#eef7ee", ec="#3d7a3d", fs=7.7)
box(38, fy, 24, 9, "Final aggregation\n(global reduction,\nnot decentralized)", fc="#eef7ee", ec="#3d7a3d", fs=7.3)
box(68, fy, 28, 9, "Re-ranked top-$k$\ndocuments returned", fc="#fdecec", ec="#8a2e2e", fs=8.0)

arrow((lx + 12, 28), (10, fy + 9), connectionstyle="arc3,rad=0.15")
arrow((comm_cx, comm_cy - 12), (25, fy + 9), connectionstyle="arc3,rad=-0.2")
arrow((32, fy + 4.5), (38, fy + 4.5))
arrow((62, fy + 4.5), (68, fy + 4.5))

leg_elems = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#c44e52', markeredgecolor='black', markersize=7, label='Originating agent (example)'),
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#4c72b0', markeredgecolor='black', markersize=7, label='Other agents'),
]
ax.legend(handles=leg_elems, loc="upper left", fontsize=7, frameon=False, bbox_to_anchor=(0.50, 0.565))

fig.tight_layout()
fig.savefig(f"{FIG}/fig1_architecture.png", dpi=300, bbox_inches="tight")
print("architecture diagram written")
