const H = require("./docx_helpers.js");
const { fs, Document, Paragraph, TextRun, AlignmentType, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, ImageRun, VerticalAlign,
  FIG, imgInches, FONT, bodyRun, P, H1, H2, Caption, CenterImg, EqRow } = H;

const m_intro = P([bodyRun(
  "UMA-GraphRAG answers a query by having every agent search its own shard of the temporal legal citation graph, exchange partial results over a sparse topology for a fixed number of rounds, and fuse the results it receives in proportion to how confident their source was. Figure 1 shows the full pipeline; this section defines each stage and its governing equations, numbered in the order they are introduced, then gives the protocol as pseudocode and analyzes its complexity."
)]);

const fig1 = CenterImg("fig1_architecture.png", 6.0);
const fig1cap = Caption("Fig. 1. UMA-GraphRAG query pipeline. Each of K agents holds a replicated shard of the temporal legal graph and estimates its own uncertainty; agents exchange low-uncertainty candidates over a sparse topology (Algorithm 1) for R rounds, fuse them by inverse-uncertainty weighting, and return a re-ranked top-k list. The final cross-agent fusion step is a global reduction, not itself decentralized -- see Section 3.4.");

const h31 = H2("Problem Formulation and Notation", "3.1");
const s31 = P([bodyRun(
  "The corpus is a set of N documents (statutes, regulations, or judicial opinions), each with a creation time t_i, a semantic embedding e_i ∈ ℝ^d, and an optional supersession pointer sup(i) recording the later document, if any, that overrules or amends it. A query is a pair (q, t_q): an embedding of the legal question and the \"as of\" date the answer must respect. The corpus is partitioned with replication factor ρ across K agents a = 1, …, K, each holding a shard D_a ⊂ {1, …, N}; with ρ = 3, each document is held by three independently-chosen agents, mirroring the redundant sharding real distributed vector stores use for fault tolerance. During the R communication rounds, agents exchange candidates only over a sparse graph G_comm — a Watts–Strogatz small-world topology with degree 4–5 — rather than all-to-all, so that per-round message volume does not grow quadratically in K; the final aggregation step across all agents after round R, however, is a global reduction rather than a peer-to-peer operation, a scope limitation on the \"decentralized\" characterization that we return to in Section 3.4."
)]);

const h32 = H2("Local Retrieval: Coarse Pruning and Temporal Validity", "3.2");
const s32a = P([bodyRun(
  "Before scoring any document exactly, each agent restricts attention to a small number of practice-area clusters. We reuse the corpus's practice-area centroids μ_c (24 in our benchmark) as a coarse index available to every agent. For a query q, an agent ranks all centroids by similarity and keeps the top C, where C itself adapts to how confident the centroid ranking is:"
)]);
const eq1 = EqRow("eq7a.png", 1, 0.30);
const eq2 = EqRow("eq7b.png", 2, 0.26);
const s32b = P([bodyRun(
  "with c₀ = 3 the base cluster budget. When the gap Δ between the best- and second-best centroid is small, the query is ambiguous across practice areas and the agent expands its search; when the gap is large, three clusters suffice. Within the surviving clusters, each agent computes an exact but agent-specific noisy score for every candidate,"
)]);
const eq3 = EqRow("eq1.png", 3, 0.30);
const s32c = P([bodyRun(
  "where σ_a is agent a's own index noise level — in a real deployment this represents a compressed, quantized, or stale local index rather than the full-precision corpus embedding; in our benchmark we assign each agent a fixed σ_a drawn from a two-tier distribution (Section 4). Every candidate is then passed through a hard temporal-validity gate before it can be ranked at all:"
)]);
const eq4 = EqRow("eq8.png", 4, 0.28);
const s32d = P([bodyRun(
  "a document is valid for query time t_q only if it existed before t_q and either was never superseded or was superseded no earlier than t_q. Invalid candidates are assigned a score of −∞ by Eq. (4) before the top-m local selection of Algorithm 1 (line 5) is applied, not after — the validity gate participates in deciding which candidates survive to the top-m, rather than filtering an already-fixed top-m post hoc, so an invalid document cannot occupy a slot that a lower-ranked valid document should have won. Validity is enforced structurally, not learned, so it cannot be defeated by an embedding that happens to score an overruled case highly. Section 5.2 tests this gate's behavior when the underlying supersession metadata is itself imperfect, rather than only against its own perfect synthetic ground truth."
)]);

const h33 = H2("Self-Assessed Uncertainty Estimation", "3.3");
const s33 = P([bodyRun(
  "For its surviving local top-m candidates, an agent estimates its own confidence with a small ensemble of M = 5 perturbed scoring heads, calibrated to its own known noise level rather than to a fixed global scale:"
)]);
const eq5 = EqRow("eq2.png", 5, 0.30);
const s33b = P([bodyRun(
  "This is the same ensemble-disagreement principle used for epistemic uncertainty in deep ensembles [16], applied at negligible extra cost since it only touches the already-small local candidate set, not the full shard. Because the perturbation scale is tied to σ_a, an agent running a known-compressed index reports correspondingly higher uncertainty for its own estimates — the self-assessment is calibrated, not omniscient: it reflects what the agent's own serving stack knows about its index quality, not the true (unobservable) error. Section 5.3 measures directly whether this self-assessment tracks realized error in practice, rather than assuming it does."
)]);

const h34 = H2("Communication and Uncertainty-Weighted Fusion", "3.4");
const s34a = P([bodyRun(
  "Each candidate's inverse uncertainty serves as its fusion weight,"
)]);
const eq6 = EqRow("eq3.png", 6, 0.34);
const s34b = P([bodyRun(
  "and when two agents' independent estimates of the same document meet — either because both hold a replica or because a candidate was relayed to them — they are combined by precision-weighted (inverse-variance) fusion, the standard way to combine independent noisy measurements of the same quantity in meta-analysis and Kalman filtering:"
)]);
const eq7 = EqRow("eq4a.png", 7, 0.30);
const eq8 = EqRow("eq4b.png", 8, 0.28);
const s34c = P([bodyRun(
  "Applied naively, this update assumes every incoming message is an independent new observation, which a loopy gossip topology does not guarantee: a relayed copy of an estimate an agent has already incorporated is not independent of what that agent already holds, and re-fusing it would silently inflate confidence without adding information. Our base protocol (Algorithm 1) does not itself guard against this. We separately implemented and tested a provenance-tracked variant that tags every estimate with its originating agent and fuses a message only when it contains at least one originating agent not already reflected in the receiving pool, discarding pure relays; Section 5.4 reports that this materially changes neither the recall level nor the finding that additional rounds reduce recall, indicating that duplicate counting is not the primary driver of that result, though it remains a correctness property the base protocol should have regardless. Before broadcasting to its neighbors in G_comm each round, an agent prunes its own pool to only the candidates it is currently most confident about, using a threshold that tightens across rounds:"
)]);
const eq9 = EqRow("eq5.png", 9, 0.30);
const eq10 = EqRow("eq6.png", 10, 0.26);
const s34d = P([bodyRun(
  "ρ_t decreases from 1.0 toward a floor of 0.3 as the round index t approaches the round budget R, so early rounds forward broadly and later rounds forward only the highest-confidence residue — this is the dynamic graph pruning referred to in the paper's title: which part of the graph remains under active consideration shrinks with each round, driven by each agent's own uncertainty rather than a fixed schedule. After R rounds, every agent's final local pool is combined by the same precision-weighted rule (Eq. 7–8) into a single ranked output. We describe this final step plainly as a centralized (or at minimum coordinator-mediated) reduction, not a further decentralized exchange: the R communication rounds are genuinely peer-to-peer over the sparse topology G_comm, but Algorithm 1's last step assumes some component — a coordinator, the querying agent, or an elected aggregator — collects every agent's final pool directly. A fully peer-to-peer deployment would instead let any single agent answer from its own converged local pool after R rounds, accepting the small additional recall loss that omitting the global step would cause; we did not evaluate that variant separately and flag it as a scope limitation on how completely \"decentralized\" the evaluated protocol is (Section 6.1)."
)]);

const h35 = H2("Algorithm and Complexity", "3.5");
const s35 = P([bodyRun(
  "Algorithm 1 gives the full per-query procedure. Local retrieval at each agent costs O(T + |D_a| · C/T) similarity evaluations, where T = 24 is the fixed number of practice-area centroids and C is the adaptive cluster budget of Eq. (2); summed across K agents holding N·ρ/K documents each on average, total per-query work is O(K·T + N·ρ·C/T), which is linear in N for fixed T and C — we return to what this means for the paper's motivating trillion-scale claim in Section 5.7. Communication cost per query is O(K · deg(G_comm) · R) messages, each carrying at most P candidates (the pool cap), so message volume also grows linearly in the number of shards K. Both costs are measured directly from executed code in Section 5, not derived only analytically."
)]);

const algoCaption = Caption("Algorithm 1. UMA-GraphRAG per-query decentralized retrieval. The validity gate (line 4) is applied before top-m selection (line 5), not after, so an invalid candidate cannot occupy a slot a valid one should have won.");
const mono = (text, opts = {}) => new TextRun({ text, font: "Consolas", size: 18, ...opts });
const algoLine = (text, indent = 0) => new Paragraph({
  spacing: { after: 0, line: 264 },
  indent: { left: 160 + indent * 220 },
  children: [mono(text)],
});
const algoLines = [
  ["Algorithm 1  UMA-GraphRAG(q, t_q, {D_a}, G_comm, {σ_a}, R, P, m, c₀)", 0],
  ["Input:  query q, time t_q, K agent shards, comm graph G_comm,", 0],
  ["        agent noise levels {σ_a}, rounds R, pool cap P,", 1],
  ["        local budget m, coarse budget c₀", 1],
  ["Output: re-ranked top-k document list", 0],
  [" 1: for each agent a = 1..K in parallel do", 0],
  [" 2:    C_a ← CoarsePrune(μ, q, c₀)                        ▷ Eq. (1)-(2)", 1],
  [" 3:    cand_a ← { i ∈ D_a : topic(i) ∈ C_a }", 1],
  [" 4:    scores_a[i] ← ⟨e_i,q⟩+noise(σ_a) if Valid(i,t_q)", 1],
  ["             else −∞,  for i ∈ cand_a          ▷ Eq. (3)-(4)", 2],
  [" 5:    cand_a ← Top-m(cand_a, scores_a)", 1],
  [" 6:    u_a ← SelfAssessedUncertainty(cand_a, q, σ_a)      ▷ Eq. (5)", 1],
  [" 7:    P_a⁽⁰⁾ ← { (i, scores_a[i], u_a[i]) : i ∈ cand_a }", 1],
  [" 8: end for", 0],
  [" 9: for t = 0 to R−1 do", 0],
  ["10:    for each agent a = 1..K in parallel do", 1],
  ["11:       τ_t ← Quantile(u-values in P_a⁽ᵗ⁾, 1−ρ_t)          ▷ Eq. (9)", 2],
  ["12:       O_a⁽ᵗ⁾ ← { i ∈ P_a⁽ᵗ⁾ : u_i ≤ τ_t }                 ▷ Eq. (10)", 2],
  ["13:       send O_a⁽ᵗ⁾ to every neighbor b ∈ N_Gcomm(a)", 2],
  ["14:    end for", 1],
  ["15:    for each agent a = 1..K in parallel do", 1],
  ["16:       for each received (i, s_b, u_b) from b ∈ N(a) do", 2],
  ["17:          P_a⁽ᵗ⁾[i] ← Fuse(P_a⁽ᵗ⁾[i], (s_b,u_b))           ▷ Eq. (6)-(8)", 3],
  ["18:       end for", 2],
  ["19:       P_a⁽ᵗ⁺¹⁾ ← Top-P(P_a⁽ᵗ⁾ by fused score)", 2],
  ["20:    end for", 1],
  ["21: end for", 0],
  ["22: merged ← FuseAcrossAgents({P_a⁽ᴿ⁾}ᵃ₌₁ᴷ)  [global reduction, ▷ Eq. (6)-(8)", 0],
  ["             not itself decentralized -- Section 3.4]", 0],
  ["23: return Top-k(merged by fused score)", 0],
];
const algoTable = new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  borders: {
    top: { style: BorderStyle.SINGLE, size: 6, color: "333333" },
    bottom: { style: BorderStyle.SINGLE, size: 6, color: "333333" },
    left: { style: BorderStyle.SINGLE, size: 4, color: "999999" },
    right: { style: BorderStyle.SINGLE, size: 4, color: "999999" },
    insideHorizontal: { style: BorderStyle.NONE },
    insideVertical: { style: BorderStyle.NONE },
  },
  rows: [new TableRow({ children: [
    new TableCell({
      shading: { type: ShadingType.CLEAR, fill: "F7F7F5" },
      margins: { top: 160, bottom: 160, left: 200, right: 200 },
      children: algoLines.map(([t, ind]) => algoLine(t, ind)),
    }),
  ] })],
});

module.exports = {
  m_intro, fig1, fig1cap, h31, s31, h32, s32a, eq1, eq2, s32b, eq3, s32c, eq4, s32d,
  h33, s33, eq5, s33b, h34, s34a, eq6, s34b, eq7, eq8, s34c, eq9, eq10, s34d,
  h35, s35, algoCaption, algoTable,
};
