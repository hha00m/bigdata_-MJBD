const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Header, Footer, PageNumber, LevelFormat, SectionType,
} = require("docx");

const H = require("./docx_helpers.js");
const I = require("./part_intro.js");
const RW = require("./part_related.js");
const M = require("./part_method.js");
const S = require("./part_setup.js");
const R = require("./part_results.js");
const C = require("./part_conclusion.js");

const { FONT, H1, H2 } = H;

const doc = new Document({
  numbering: {
    config: [
      { reference: "contrib-list", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] },
      { reference: "lim-list", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] },
      { reference: "fut-list", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 540, hanging: 360 } } } }] },
    ],
  },
  styles: {
    default: {
      document: { run: { font: FONT, size: 22 } },
      heading1: { run: { font: FONT, bold: true, size: 26 }, paragraph: { spacing: { before: 320, after: 160 } } },
      heading2: { run: { font: FONT, bold: true, size: 23 }, paragraph: { spacing: { before: 240, after: 120 } } },
    },
  },
  sections: [
    {
      properties: {
        page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      },
      headers: {
        default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "UMA-GraphRAG", size: 16, font: FONT, color: "888888" })] })] }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, font: FONT })],
          })],
        }),
      },
      children: [
        I.title, I.authors, I.affil, I.authorNote,
        I.abstractHeading, I.abstractText, I.keywords,

        H1("Introduction", 1),
        I.s1_p1, I.s1_p2, I.s1_p3, I.s1_contrib_lead, ...I.contribParas, I.s1_roadmap,

        H1("Related Work", 2),
        RW.rw_heading_a, RW.rw_a,
        RW.rw_heading_b, RW.rw_b,
        RW.rw_heading_c, RW.rw_c,
        RW.rw_heading_d, RW.rw_d,

        H1("Proposed Method: UMA-GraphRAG", 3),
        M.m_intro, M.fig1, M.fig1cap,
        M.h31, M.s31,
        M.h32, M.s32a, M.eq1, M.eq2, M.s32b, M.eq3, M.s32c, M.eq4, M.s32d,
        M.h33, M.s33, M.eq5, M.s33b,
        M.h34, M.s34a, M.eq6, M.s34b, M.eq7, M.eq8, M.s34c, M.eq9, M.eq10, M.s34d,
        M.h35, M.s35, M.algoCaption, M.algoTable,

        H1("Experimental Setup", 4),
        S.h41, S.s41a, S.s41b, S.cap1, S.table1,
        S.h42, S.s42,
        S.h43, S.s43,
        S.h44, S.s44, S.cap2, S.table2,

        H1("Results and Discussion", 5),
        R.h51, R.s51a, R.s51b, R.s51c, R.s51d, R.cap3, R.table3, R.fig5, R.fig5cap,
        R.h52, R.s52a, R.s52b, R.fig_noise, R.fig_noise_cap, R.s52c,
        R.h53, R.s53a, R.s53b, R.fig2, R.fig2cap, R.s53c,
        R.h54, R.s54, R.fig3, R.fig3cap,
        R.h55, R.s55a, R.s55b, R.fig_prov, R.fig_prov_cap, R.s55c,
        R.h56, R.s56a, R.s56b, R.fig_calib, R.fig_calib_cap,
        R.h57, R.s57,

        C.h6, C.s6_p1, C.s6_p2, C.s6_p3,
        C.h6a, ...C.limParas,
        C.h6b, ...C.futParas,
        C.h6c, C.s6c,
        C.h6d, C.s6d1, C.s6d2, C.s6d3, C.s6d4,

        C.refsHeading, ...C.refParas,
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("/home/claude/uma_graphrag/UMA-GraphRAG_manuscript.docx", buf);
  console.log("Wrote manuscript, bytes:", buf.length);
}).catch((e) => {
  console.error("BUILD FAILED:", e);
  process.exit(1);
});
