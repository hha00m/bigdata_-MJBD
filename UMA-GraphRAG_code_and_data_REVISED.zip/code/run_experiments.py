"""
run_experiments.py
Runs three experiment blocks and writes CSVs to ../data/:

1. scaling sweep   -- recall, work-units, message cost, and wall-clock
                       latency vs. corpus size N (single seed per scale,
                       standard practice for large-N scaling curves).
2. main comparison -- 3 seeds x 150 queries at a fixed representative scale
                       (N=100,000) for the headline results table with
                       reported std.
3. ablations       -- (a) reliability-heterogeneity sweep (does the gap
                       between UMA and MultiAgentUniform depend on how
                       unreliable the low-fidelity agents are), and
                       (b) communication-round budget sweep.
"""
import time
import csv
import numpy as np

from graph_gen import generate_temporal_legal_graph
from framework import (
    partition_agents, comm_graph, agent_reliability,
    run_query_uma, run_query_multiagent_uniform, run_query_static_prune,
    run_query_full, oracle_topk, recall_at_k, validity_precision,
)

OUT = "/home/claude/uma_graphrag/data"


def make_queries(graph, n_q, seed, frac_lo=0.4):
    rng = np.random.default_rng(seed)
    n_nodes = len(graph["timestamps"])
    n_topics = graph["topic_centers"].shape[0]
    dim = graph["embeddings"].shape[1]
    queries = []
    for _ in range(n_q):
        t_topic = rng.integers(0, n_topics)
        qv = graph["topic_centers"][t_topic] + rng.normal(scale=0.3, size=dim)
        qv = qv / np.linalg.norm(qv)
        qt = rng.integers(int(frac_lo * n_nodes), n_nodes)
        queries.append((qv.astype(np.float32), int(qt)))
    return queries


def k_for_scale(n):
    return int(max(8, round(n / 4000)))


def scaling_sweep():
    scales = [20000, 100000, 400000, 1000000]
    n_queries_by_scale = {20000: 80, 100000: 60, 400000: 45, 1000000: 30}
    rows = []
    for n in scales:
        t_gen0 = time.time()
        g = generate_temporal_legal_graph(n, seed=1)
        gen_time = time.time() - t_gen0
        all_ids = np.arange(n)
        K = k_for_scale(n)
        shards = partition_agents(n, K, replication=3, seed=1)
        cg = comm_graph(K, degree=5, seed=1)
        sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=1)

        queries = make_queries(g, n_queries_by_scale[n], seed=2024)
        metrics = {m: dict(recall=[], work=[], msgs=[], msg_bytes=[], lat=[]) for m in
                   ["uma", "uniform", "static", "full"]}
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)

            t0 = time.perf_counter()
            r = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            dt = time.perf_counter() - t0
            metrics["uma"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            metrics["uma"]["work"].append(r["work"]); metrics["uma"]["msgs"].append(r["msgs"])
            metrics["uma"]["msg_bytes"].append(r["msg_bytes"]); metrics["uma"]["lat"].append(dt)

            t0 = time.perf_counter()
            r = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            dt = time.perf_counter() - t0
            metrics["uniform"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            metrics["uniform"]["work"].append(r["work"]); metrics["uniform"]["msgs"].append(r["msgs"])
            metrics["uniform"]["msg_bytes"].append(r["msg_bytes"]); metrics["uniform"]["lat"].append(dt)

            t0 = time.perf_counter()
            r = run_query_static_prune(g, all_ids, qv, qt)
            dt = time.perf_counter() - t0
            metrics["static"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            metrics["static"]["work"].append(r["work"]); metrics["static"]["msgs"].append(0)
            metrics["static"]["msg_bytes"].append(0); metrics["static"]["lat"].append(dt)

            t0 = time.perf_counter()
            r = run_query_full(g, all_ids, qv, qt)
            dt = time.perf_counter() - t0
            metrics["full"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            metrics["full"]["work"].append(r["work"]); metrics["full"]["msgs"].append(0)
            metrics["full"]["msg_bytes"].append(0); metrics["full"]["lat"].append(dt)

        for m in metrics:
            rows.append(dict(
                n_nodes=n, n_edges=len(g["edge_src"]), K=K, method=m,
                recall=np.nanmean(metrics[m]["recall"]),
                work=np.mean(metrics[m]["work"]),
                msgs=np.mean(metrics[m]["msgs"]),
                msg_bytes=np.mean(metrics[m]["msg_bytes"]),
                latency_ms=np.mean(metrics[m]["lat"]) * 1000,
                gen_time_s=gen_time,
            ))
        print(f"[scaling] n={n} K={K} done ({time.time()-t_gen0:.1f}s incl. gen)")

    with open(f"{OUT}/scaling_results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return rows


def main_comparison_table():
    n = 100000
    K = k_for_scale(n)
    rows = []
    for seed in [1, 2, 3]:
        g = generate_temporal_legal_graph(n, seed=seed)
        all_ids = np.arange(n)
        shards = partition_agents(n, K, replication=3, seed=seed)
        cg = comm_graph(K, degree=5, seed=seed)
        sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=seed)
        queries = make_queries(g, 150, seed=1000 + seed)

        per_method = {m: dict(recall=[], vp=[], work=[]) for m in
                      ["uma", "uniform", "static", "full", "semantic"]}
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)

            r = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            per_method["uma"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["uma"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["uma"]["work"].append(r["work"])

            r = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            per_method["uniform"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["uniform"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["uniform"]["work"].append(r["work"])

            r = run_query_static_prune(g, all_ids, qv, qt)
            per_method["static"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["static"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["static"]["work"].append(r["work"])

            r = run_query_full(g, all_ids, qv, qt)
            per_method["full"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["full"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["full"]["work"].append(r["work"])

            r = run_query_full(g, all_ids, qv, qt, validity_aware=False)
            per_method["semantic"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["semantic"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["semantic"]["work"].append(r["work"])

        for m in per_method:
            rows.append(dict(
                seed=seed, method=m,
                recall=np.nanmean(per_method[m]["recall"]),
                validity_precision=np.nanmean(per_method[m]["vp"]),
                work=np.mean(per_method[m]["work"]),
            ))
        print(f"[main table] seed={seed} done")

    with open(f"{OUT}/main_comparison.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return rows


def ablation_sweeps():
    n = 100000
    K = k_for_scale(n)
    g = generate_temporal_legal_graph(n, seed=1)
    all_ids = np.arange(n)
    shards = partition_agents(n, K, replication=3, seed=1)
    cg = comm_graph(K, degree=5, seed=1)
    queries = make_queries(g, 100, seed=555)

    rows_het = []
    for sigma_high in [0.008, 0.02, 0.035, 0.05, 0.08, 0.12]:
        sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=sigma_high, seed=1)
        uma_r, uni_r = [], []
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)
            r1 = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            r2 = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            uma_r.append(recall_at_k(r1["top_ids"], oracle))
            uni_r.append(recall_at_k(r2["top_ids"], oracle))
        rows_het.append(dict(sigma_high=sigma_high, uma_recall=np.nanmean(uma_r),
                              uniform_recall=np.nanmean(uni_r),
                              gap=np.nanmean(uma_r) - np.nanmean(uni_r)))
        print(f"[ablation-heterogeneity] sigma_high={sigma_high} done")

    with open(f"{OUT}/ablation_heterogeneity.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows_het[0].keys()))
        w.writeheader(); w.writerows(rows_het)

    rows_rounds = []
    sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=1)
    for rounds in [0, 1, 2, 3, 4, 5]:
        uma_r, uni_r = [], []
        msgs_uma = []
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)
            r1 = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=rounds, pool_cap=25, local_m=15)
            r2 = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=rounds, pool_cap=25, local_m=15)
            uma_r.append(recall_at_k(r1["top_ids"], oracle))
            uni_r.append(recall_at_k(r2["top_ids"], oracle))
            msgs_uma.append(r1["msgs"])
        rows_rounds.append(dict(rounds=rounds, uma_recall=np.nanmean(uma_r),
                                 uniform_recall=np.nanmean(uni_r), avg_msgs=np.mean(msgs_uma)))
        print(f"[ablation-rounds] rounds={rounds} done")

    with open(f"{OUT}/ablation_rounds.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows_rounds[0].keys()))
        w.writeheader(); w.writerows(rows_rounds)


if __name__ == "__main__":
    t0 = time.time()
    scaling_sweep()
    print(f"scaling sweep done in {time.time()-t0:.1f}s")
    t0 = time.time()
    main_comparison_table()
    print(f"main table done in {time.time()-t0:.1f}s")
    t0 = time.time()
    ablation_sweeps()
    print(f"ablations done in {time.time()-t0:.1f}s")
