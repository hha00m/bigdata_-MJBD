"""
calibration_analysis.py
Tests whether each agent's self-assessed uncertainty (Eq. 2) is actually
predictive of its realized scoring error, rather than just assuming it. For
a sample of (agent, candidate, query) observations we record the agent's
noisy score, its self-assessed uncertainty, and the TRUE noiseless cosine
similarity (the ground truth the agent is trying to estimate); we then
report the correlation between uncertainty and squared error, a calibration
binning plot's underlying data, and an expected-calibration-error-style
summary.
"""
import csv
import numpy as np
from scipy import stats
from graph_gen import generate_temporal_legal_graph
from framework import (
    partition_agents, agent_reliability, _local_candidates,
    _ensemble_uncertainty_selfassessed,
)

OUT = "/home/claude/uma_graphrag/data"


def main():
    n = 100000
    g = generate_temporal_legal_graph(n, seed=1)
    K = max(8, round(n / 4000))
    shards = partition_agents(n, K, replication=3, seed=1)
    sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=1)

    rng = np.random.default_rng(42)
    n_q = 100
    records = []
    for qi in range(n_q):
        t_topic = rng.integers(0, g["topic_centers"].shape[0])
        qv = g["topic_centers"][t_topic] + rng.normal(scale=0.3, size=g["embeddings"].shape[1])
        qv = qv / np.linalg.norm(qv)
        qt = int(rng.integers(int(0.4 * n), n))

        for a in range(K):
            noise_rng = np.random.default_rng(qi * 100003 + a)
            cand, noisy_scores, _ = _local_candidates(g, shards[a], qv, qt, base_c=3, adaptive=True,
                                                        local_m=15, sigma_a=sigma[a], noise_rng=noise_rng)
            if len(cand) == 0:
                continue
            true_scores = g["embeddings"][cand] @ qv
            u, _ = _ensemble_uncertainty_selfassessed(g, cand, qv, sigma[a], seed=qi * 7 + a)
            sq_err = (noisy_scores - true_scores) ** 2
            for uu, se, sig in zip(u, sq_err, np.full(len(cand), sigma[a])):
                records.append((float(uu), float(se), float(sig)))

    u_arr = np.array([r[0] for r in records])
    err_arr = np.array([r[1] for r in records])
    sigma_arr = np.array([r[2] for r in records])

    rho, p_rho = stats.spearmanr(u_arr, err_arr)
    pear_r, p_pear = stats.pearsonr(u_arr, err_arr)

    # calibration bins: does higher self-assessed uncertainty correspond to
    # higher realized error, on average, in a monotone way?
    n_bins = 10
    order = np.argsort(u_arr)
    bin_edges = np.array_split(order, n_bins)
    bin_rows = []
    for i, idx in enumerate(bin_edges):
        bin_rows.append(dict(
            bin=i, n=len(idx),
            mean_uncertainty=float(u_arr[idx].mean()),
            mean_sq_error=float(err_arr[idx].mean()),
            rmse=float(np.sqrt(err_arr[idx].mean())),
        ))
        print(f"bin {i}: mean_u={u_arr[idx].mean():.5f}  mean_sq_err={err_arr[idx].mean():.5f}  rmse={np.sqrt(err_arr[idx].mean()):.5f}  n={len(idx)}")

    # also: correlation between agent's TRUE noise level sigma_a and its
    # mean self-assessed uncertainty (agent-level calibration sanity check)
    rho_sigma, p_sigma = stats.spearmanr(sigma_arr, u_arr)

    print(f"\nSpearman rho(uncertainty, sq_error) = {rho:.4f} (p={p_rho:.2e}), n={len(u_arr)}")
    print(f"Pearson r(uncertainty, sq_error)    = {pear_r:.4f} (p={p_pear:.2e})")
    print(f"Spearman rho(true sigma_a, uncertainty) = {rho_sigma:.4f} (p={p_sigma:.2e})")

    with open(f"{OUT}/calibration_bins.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(bin_rows[0].keys()))
        w.writeheader()
        w.writerows(bin_rows)

    with open(f"{OUT}/calibration_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["n_obs", "spearman_rho", "spearman_p", "pearson_r", "pearson_p",
                                           "sigma_uncertainty_rho", "sigma_uncertainty_p"])
        w.writeheader()
        w.writerow(dict(n_obs=len(u_arr), spearman_rho=rho, spearman_p=p_rho, pearson_r=pear_r, pearson_p=p_pear,
                         sigma_uncertainty_rho=rho_sigma, sigma_uncertainty_p=p_sigma))


if __name__ == "__main__":
    main()
