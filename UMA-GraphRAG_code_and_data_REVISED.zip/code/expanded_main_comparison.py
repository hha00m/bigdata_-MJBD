import csv
import time
import numpy as np
from scipy import stats
from graph_gen import generate_temporal_legal_graph
from framework import (
    partition_agents, comm_graph, agent_reliability, build_hnsw_index,
    run_query_uma, run_query_multiagent_uniform,
    run_query_static_prune, run_query_full, run_query_hnsw,
    oracle_topk, recall_at_k, validity_precision,
)

OUT = "/home/claude/uma_graphrag/data"


def make_queries(graph, n_q, seed, frac_lo=0.4):
    rng = np.random.default_rng(seed)
    n_nodes = len(graph["timestamps"])
    n_topics = graph["topic_centers"].shape[0]
    dim = graph["embeddings"].shape[1]
    queries = []
    for _ in range(n_q):
        t_topic = rng.integers(0, n_topics)
        qv = graph["topic_centers"][t_topic] + rng.normal(scale=0.3, size=dim)
        qv = qv / np.linalg.norm(qv)
        qt = rng.integers(int(frac_lo * n_nodes), n_nodes)
        queries.append((qv.astype(np.float32), int(qt)))
    return queries


def cohens_d(a, b):
    a, b = np.asarray(a), np.asarray(b)
    pooled_sd = np.sqrt(((len(a) - 1) * a.std(ddof=1) ** 2 + (len(b) - 1) * b.std(ddof=1) ** 2) / (len(a) + len(b) - 2))
    return (a.mean() - b.mean()) / pooled_sd if pooled_sd > 0 else np.nan


def ci95(x):
    x = np.asarray(x)
    m = x.mean()
    se = x.std(ddof=1) / np.sqrt(len(x))
    return m - 1.96 * se, m + 1.96 * se


def expanded_main_comparison(n_seeds=8, n_queries=150):
    n = 100000
    K = max(8, round(n / 4000))
    per_seed_uma, per_seed_uniform = [], []
    rows = []
    for seed in range(1, n_seeds + 1):
        g = generate_temporal_legal_graph(n, seed=seed)
        all_ids = np.arange(n)
        shards = partition_agents(n, K, replication=3, seed=seed)
        cg = comm_graph(K, degree=5, seed=seed)
        sigma = agent_reliability(K, low_fidelity_frac=0.5, sigma_low=0.004, sigma_high=0.05, seed=seed)
        hnsw_idx = build_hnsw_index(g, ef_construction=200, M=16, ef_search=80)
        queries = make_queries(g, n_queries, seed=1000 + seed)

        per_method = {m: dict(recall=[], vp=[], work=[]) for m in
                      ["uma", "uniform", "static", "full", "semantic", "hnsw"]}
        for qi, (qv, qt) in enumerate(queries):
            oracle = oracle_topk(g, all_ids, qv, qt, k=10)

            r = run_query_uma(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            per_method["uma"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["uma"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["uma"]["work"].append(r["work"])

            r = run_query_multiagent_uniform(g, shards, cg, qv, qt, sigma, query_seed=qi, rounds=3, pool_cap=25, local_m=15)
            per_method["uniform"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["uniform"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["uniform"]["work"].append(r["work"])

            r = run_query_static_prune(g, all_ids, qv, qt)
            per_method["static"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["static"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["static"]["work"].append(r["work"])

            r = run_query_full(g, all_ids, qv, qt)
            per_method["full"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["full"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["full"]["work"].append(r["work"])

            r = run_query_full(g, all_ids, qv, qt, validity_aware=False)
            per_method["semantic"]["recall"].append(recall_at_k(r["top_ids"], oracle))
            per_method["semantic"]["vp"].append(validity_precision(g, r["top_ids"], qt))
            per_method["semantic"]["work"].append(r["work"])

            r_top = run_query_hnsw(g, hnsw_idx, qv, qt, k=10, fetch=200)
            per_method["hnsw"]["recall"].append(recall_at_k(r_top["top_ids"], oracle))
            per_method["hnsw"]["vp"].append(validity_precision(g, r_top["top_ids"], qt))
            per_method["hnsw"]["work"].append(r_top["work"])

        for m in per_method:
            rows.append(dict(
                seed=seed, method=m,
                recall=np.nanmean(per_method[m]["recall"]),
                validity_precision=np.nanmean(per_method[m]["vp"]),
                work=np.mean(per_method[m]["work"]),
            ))
        per_seed_uma.append(np.nanmean(per_method["uma"]["recall"]))
        per_seed_uniform.append(np.nanmean(per_method["uniform"]["recall"]))
        print(f"[expanded main] seed={seed} done  uma={per_seed_uma[-1]:.4f} uniform={per_seed_uniform[-1]:.4f}")

    with open(f"{OUT}/main_comparison_expanded.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    per_seed_uma = np.array(per_seed_uma)
    per_seed_uniform = np.array(per_seed_uniform)
    diff = per_seed_uma - per_seed_uniform
    t_stat, p_val = stats.ttest_rel(per_seed_uma, per_seed_uniform)
    d = cohens_d(per_seed_uma, per_seed_uniform)
    ci_uma = ci95(per_seed_uma)
    ci_uniform = ci95(per_seed_uniform)
    summary = dict(
        n_seeds=n_seeds,
        uma_mean=per_seed_uma.mean(), uma_std=per_seed_uma.std(ddof=1),
        uma_ci_lo=ci_uma[0], uma_ci_hi=ci_uma[1],
        uniform_mean=per_seed_uniform.mean(), uniform_std=per_seed_uniform.std(ddof=1),
        uniform_ci_lo=ci_uniform[0], uniform_ci_hi=ci_uniform[1],
        mean_diff=diff.mean(), diff_std=diff.std(ddof=1),
        paired_t=t_stat, paired_p=p_val, cohens_d=d,
        n_seeds_positive=int((diff > 0).sum()), n_seeds_negative=int((diff < 0).sum()),
    )
    print("SUMMARY:", summary)
    with open(f"{OUT}/main_comparison_expanded_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary.keys()))
        w.writeheader()
        w.writerow(summary)
    return summary


if __name__ == "__main__":
    t0 = time.time()
    expanded_main_comparison(n_seeds=8, n_queries=150)
    print(f"done in {time.time()-t0:.1f}s")
