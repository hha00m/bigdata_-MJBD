const H = require("./docx_helpers.js");
const { Paragraph, Table, TableRow, TableCell, WidthType, ShadingType, AlignmentType, VerticalAlign,
  FONT, bodyRun, P, H2, Caption, TCell } = H;

const h41 = H2("Synthetic Temporal Legal Citation Benchmark", "4.1");
const s41a = P([bodyRun(
  "No public dataset combines a citation graph at the scale we target with ground-truth supersession (overruling/amendment) labels and controllable query-time semantics, so we built a synthetic generator; every number reported below comes from synthetic data, generated and scored by code we ran ourselves and deliver alongside this paper, and we flag prominently wherever a finding should not be read as a claim about real case law. Documents arrive in timestamp order; each is assigned a latent practice-area topic (24 topics) and an embedding drawn from that topic's centroid plus Gaussian noise, then L2-normalized (d = 16). Citation edges follow a recency- and similarity-weighted preferential-attachment rule restricted to a 512-document lookback window, so citing documents preferentially reference recent, topically related priors, consistent with how citation growth is modeled in the citation-network literature. A configurable fraction of documents (1.5% in our benchmark) are later superseded by a randomly chosen later document, recording an explicit supersession pointer. Queries are constructed by sampling a topic center plus noise for the semantic component and a query time uniformly from the most recent 60% of the corpus's timestamp range, so that a meaningful fraction of the corpus is deliberately excluded by the temporal filter on every query. An oracle top-10 is computed by brute-force search restricted to valid documents, giving a ground truth against which every method's recall is measured."
)]);
const s41b = P([bodyRun(
  "We generated four corpus scales — 20,000; 100,000; 400,000; and 1,000,000 documents — with 119,550 through 6,006,226 edges respectively, all on a single CPU core with under 4 GB of RAM; generation time ranged from 1.4 s to 72.1 s. All generator and experiment code, and the full result CSVs, are delivered alongside this manuscript."
)]);

const h42 = H2("Baselines", "4.2")
const s42 = P([bodyRun(
  "FullGraphRAG scores every valid document in the corpus by brute-force cosine similarity — a centralized, single-index upper bound on accuracy with no scalability mechanism and, as Section 5.1 shows, a substantially more expensive stand-in for \"centralized search\" than a real system would use. HNSW-ANN is that more realistic stand-in: a single tuned hnswlib index (cosine space, M = 16, ef_construction = 200, ef_search = 80) built once over the full corpus, queried with the standard over-fetch-then-filter pattern (retrieve 200 nearest neighbors, then apply the same temporal-validity gate as every other method, then take the top 10 valid survivors) since ANN indices do not natively support arbitrary predicate pre-filtering. StaticPruneRAG runs on a single agent with the same coarse practice-area pruning as the proposed method but a fixed, non-adaptive cluster budget (c₀ = 3, no expansion), no communication, and no uncertainty weighting; it isolates the benefit of pruning alone. MultiAgentUniform uses the identical sharding, replication, comm topology, coarse pruning, and per-agent noise realization as UMA-GraphRAG, but fuses candidates by unweighted averaging and prunes by a fixed drop-the-weaker-half rule instead of an uncertainty quantile; it isolates the specific benefit of uncertainty-awareness from the benefit of decentralization itself. SemanticOnly runs FullGraphRAG's centralized search but with the temporal-validity gate disabled, ranking purely by embedding similarity; it isolates the cost of ignoring temporal validity. Both MultiAgentUniform and UMA-GraphRAG receive exactly the same noisy local observations per agent per query (identical random seeds), so any difference between them is attributable only to the fusion and pruning rule, not to differing inputs. We additionally implemented, for the ablation in Section 5.5, a provenance-tracked variant of UMA-GraphRAG that tags every candidate with its originating agent and refuses to re-fuse a relayed duplicate of an already-incorporated observation."
)]);

const h43 = H2("Metrics", "4.3");
const s43 = P([bodyRun(
  "Recall@10 is the overlap between a method's top-10 output and the oracle top-10, divided by 10. Validity precision@10 is the fraction of a method's top-10 output that satisfies the temporal-validity predicate (Eq. 4) at the query time, evaluated against whatever metadata the method itself used; Section 5.2 separately reports true validity precision and recall vs. true oracle, which score a method's output against uncorrupted ground truth even when the method was given a deliberately noisy view of the supersession record. Work units count the number of embedding similarity evaluations actually performed — centroid comparisons plus candidate scoring plus ensemble evaluations, or the fixed over-fetch budget for HNSW-ANN — and is measured directly from executed code, not estimated analytically. Messages and message bytes count the actual gossip traffic generated per query. Latency is wall-clock time for the whole query pipeline; for HNSW-ANN this is measured directly from the production hnswlib implementation and is a reasonable proxy for real deployment performance, while for our own decentralized methods it reflects a single-core sequential Python simulation and should be read only as a secondary, explicitly caveated metric (Section 5.3), with work units as the primary scalability metric. Section 5.6 additionally reports Spearman correlation between an agent's self-assessed uncertainty and its realized squared scoring error, as a calibration check on the mechanism the fusion and pruning rules depend on."
)]);

const h44 = H2("Hyperparameters and Reproducibility", "4.4");
const s44 = P([bodyRun(
  "Unless swept as the independent variable in an ablation, we use: replication ρ = 3, communication rounds R = 3, pool cap P = 25, local candidate budget m = 15, coarse cluster base budget c₀ = 3, ensemble size M = 5, comm graph degree 4–5 (Watts–Strogatz, rewiring probability 0.1), and shard count K = max(8, round(N/4000)) — 8, 25, 100, and 250 at our four corpus scales. Agent reliability is drawn once per experiment from a two-tier distribution: 50% of agents are \"low-fidelity\" with noise σ = 0.05, the rest \"high-fidelity\" with σ = 0.004, unless swept directly in Section 5.4. The main comparison (Section 5.1) uses 8 independently generated corpus/sharding seeds at 150 queries each; the scaling study and single-topology ablations (Sections 5.2–5.6) use one fixed seed with 100–150 queries, a lighter-weight design we chose to cover more scales and sweep points within the compute budget available, and which we flag explicitly as a lower-confidence design than the main comparison in Section 6.1. All code, the exact CSV outputs of every run, and the random seeds used are included with this submission; Table 1 and Table 2 summarize the generated corpora and the fixed hyperparameters respectively."
)]);

// ---- Table 1: dataset summary ----
const dtRows = [
  ["N (documents)", "Edges", "K (shards)", "Overruled docs", "Generation time"],
  ["20,000", "119,550", "8", "300 (1.5%)", "1.4 s"],
  ["100,000", "599,201", "25", "1,500 (1.5%)", "7.8 s"],
  ["400,000", "2,398,361", "100", "6,000 (1.5%)", "35.8 s"],
  ["1,000,000", "6,006,226", "250", "15,000 (1.5%)", "72.1 s"],
];
const mkRow = (cells, header = false) => new TableRow({
  children: cells.map((c) => TCell(c, { bold: header, shade: header })),
});
const table1 = new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  rows: dtRows.map((r, i) => mkRow(r, i === 0)),
});
const cap1 = Caption("Table 1. Synthetic temporal legal citation benchmark: corpus scales used in the scaling study (Section 5.3), generated and timed on a single CPU core.");
// ---- Table 2: hyperparameters ----
const hpRows = [
  ["Parameter", "Symbol", "Default value"],
  ["Replication factor", "ρ", "3"],
  ["Communication rounds", "R", "3 (swept 0-5 in Section 5.5)"],
  ["Pool cap", "P", "25"],
  ["Local candidate budget", "m", "15"],
  ["Coarse cluster base budget", "c₀", "3 (adaptive up to 9)"],
  ["Ensemble size", "M", "5"],
  ["Comm. graph degree", "—", "4-5 (Watts-Strogatz, p = 0.1)"],
  ["Shard count", "K", "max(8, round(N/4000))"],
  ["Low-fidelity agent fraction", "—", "0.5"],
  ["Low/high-fidelity noise σ", "σ_low, σ_high", "0.004 / 0.05 (swept in Section 5.4)"],
  ["Embedding dimension", "d", "16"],
  ["Practice-area topics", "T", "24"],
];
const table2 = new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  rows: hpRows.map((r, i) => mkRow(r, i === 0)),
});
const cap2 = Caption("Table 2. Default hyperparameters. Values swept as an ablation's independent variable are noted.");

module.exports = { h41, s41a, s41b, h42, s42, h43, s43, h44, s44, table1, cap1, table2, cap2 };
