"""
graph_gen.py
Synthetic temporal legal citation graph generator.

Each node represents a legal document (statute, regulation, or judicial
opinion). Every document has:
  - a creation timestamp (integer "term index", monotonically increasing)
  - a latent semantic embedding (float32 vector)
  - an optional "superseded_by" pointer: the index of a later document that
    overrules or amends it (or -1 if still good law)

Citation edges are generated with a preferential-attachment rule biased
toward semantically similar, still-valid prior documents, which mimics the
tendency of judicial opinions and statutory amendments to cite recent,
topically related, currently authoritative sources (Ravasz-Barabasi-style
temporal citation growth, adapted with a legal-validity filter).

All operations are vectorized / array-based so that graphs with millions of
nodes fit in a few hundred MB of RAM and generate in well under a minute on
a single CPU core.
"""
import numpy as np


def generate_temporal_legal_graph(
    n_nodes: int,
    embed_dim: int = 16,
    avg_out_degree: float = 6.0,
    n_topics: int = 24,
    overrule_prob: float = 0.015,
    seed: int = 0,
):
    """Generate a synthetic temporal legal citation graph.

    Returns a dict with:
      embeddings   : (N, D) float32, L2-normalized latent semantic vectors
      timestamps   : (N,)   int32, creation term index (sorted ascending)
      superseded_by: (N,)   int32, index of overruling/amending doc, or -1
      edge_src     : (E,)   int32, citing document
      edge_dst     : (E,)   int32, cited document (dst.timestamp < src.timestamp)
      topic_id     : (N,)   int32, latent topic cluster (for readability only)
    """
    rng = np.random.default_rng(seed)

    # --- latent topic structure -------------------------------------------------
    topic_centers = rng.normal(size=(n_topics, embed_dim)).astype(np.float32)
    topic_centers /= np.linalg.norm(topic_centers, axis=1, keepdims=True)
    topic_id = rng.integers(0, n_topics, size=n_nodes).astype(np.int32)
    noise = rng.normal(scale=0.35, size=(n_nodes, embed_dim)).astype(np.float32)
    embeddings = topic_centers[topic_id] + noise
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True)

    # --- temporal ordering: documents arrive in timestamp order -----------------
    timestamps = np.arange(n_nodes, dtype=np.int32)

    # --- citation edges: each new doc cites ~Poisson(avg_out_degree) priors -----
    # Preferential attachment weight = recency decay * semantic similarity to a
    # small candidate pool sampled from the existing graph (keeps generation
    # near O(N * avg_out_degree) instead of O(N^2)).
    out_deg = rng.poisson(lam=avg_out_degree, size=n_nodes).astype(np.int32)
    out_deg[0] = 0
    total_edges = int(out_deg[1:].sum())
    edge_src = np.empty(total_edges, dtype=np.int32)
    edge_dst = np.empty(total_edges, dtype=np.int32)

    window = 512  # recency window each citing document draws candidates from
    ptr = 0
    for i in range(1, n_nodes):
        k = out_deg[i]
        if k == 0:
            continue
        lo = max(0, i - window)
        cand = np.arange(lo, i)
        # combined weight = recency decay * semantic similarity, both cheap
        recency_w = np.exp(-(i - cand) / (window * 0.25))
        sims = embeddings[cand] @ embeddings[i]
        w = recency_w * (sims - sims.min() + 1e-3)
        sel_n = min(k, len(cand))
        if sel_n == 0:
            continue
        probs = w / w.sum()
        chosen = rng.choice(cand, size=sel_n, replace=False, p=probs)
        edge_src[ptr:ptr + sel_n] = i
        edge_dst[ptr:ptr + sel_n] = chosen
        ptr += sel_n
    edge_src = edge_src[:ptr]
    edge_dst = edge_dst[:ptr]

    # --- temporal validity: some documents get overruled/amended later ----------
    superseded_by = -np.ones(n_nodes, dtype=np.int32)
    n_overruled = int(n_nodes * overrule_prob)
    if n_overruled > 0:
        candidates = rng.choice(n_nodes - 1, size=min(n_overruled, n_nodes - 1), replace=False)
        for c in candidates:
            # the overruling document must postdate the overruled one
            lo = c + 1
            if lo >= n_nodes:
                continue
            overruler = rng.integers(lo, n_nodes)
            superseded_by[c] = overruler

    return dict(
        embeddings=embeddings.astype(np.float32),
        timestamps=timestamps,
        superseded_by=superseded_by,
        edge_src=edge_src,
        edge_dst=edge_dst,
        topic_id=topic_id,
        topic_centers=topic_centers.astype(np.float32),
    )


def is_valid_at(graph, doc_ids, query_time, superseded_by_override=None):
    """Vectorized check: is doc still good law strictly before query_time, i.e.
    not created after query_time and not (yet) superseded by query_time.
    superseded_by_override lets a caller substitute a noisy view of the
    supersession metadata (simulating imperfect citator data) while leaving
    the graph's ground truth untouched -- see noisy_superseded_by()."""
    sup_array = graph["superseded_by"] if superseded_by_override is None else superseded_by_override
    ts = graph["timestamps"][doc_ids]
    sup = sup_array[doc_ids]
    created_ok = ts < query_time
    sup_ts = np.where(sup >= 0, graph["timestamps"][np.clip(sup, 0, len(graph["timestamps"]) - 1)], np.iinfo(np.int32).max)
    still_valid = np.where(sup >= 0, sup_ts >= query_time, True)
    return created_ok & still_valid


def noisy_superseded_by(graph, seed, p_missing=0.0, p_false=0.0):
    """A noisy view of the supersession metadata a system might actually have
    access to in practice (e.g. an imperfect or lagging citator service),
    used to test whether the temporal-validity gate degrades gracefully
    rather than only ever being evaluated against its own perfect ground
    truth. p_missing: probability a genuine supersession is not on record
    (the system believes the document is still good law). p_false: probability
    a non-superseded document is incorrectly flagged as superseded."""
    rng = np.random.default_rng(seed)
    sup = graph["superseded_by"].copy()
    ts = graph["timestamps"]
    has_sup = sup >= 0
    hide_mask = has_sup & (rng.random(len(sup)) < p_missing)
    sup[hide_mask] = -1
    no_sup_idx = np.nonzero((~has_sup) & (rng.random(len(sup)) < p_false))[0]
    for i in no_sup_idx:
        if i + 1 < len(ts):
            sup[i] = rng.integers(i + 1, len(ts))
    return sup


if __name__ == "__main__":
    g = generate_temporal_legal_graph(20000, seed=1)
    print("nodes:", len(g["timestamps"]), "edges:", len(g["edge_src"]))
    print("overruled:", int((g["superseded_by"] >= 0).sum()))
