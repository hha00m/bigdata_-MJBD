const H = require("./docx_helpers.js");
const { fs, Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  ImageRun, PageBreak, VerticalAlign,
  FIG, imgInches, FONT, bodyRun, P, H1, H2, Caption, CenterImg, EqRow, TCell } = H;

const title = new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 120 },
  children: [new TextRun({ text: "Uncertainty-Weighted Multi-Agent GraphRAG Framework for Large-Scale Temporal Legal Corpus Analysis", bold: true, size: 32, font: FONT })],
});
const authors = new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 40 },
  children: [new TextRun({ text: "Hayder Algabri", size: 22, font: FONT })],
});
const affil = new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 60 },
  children: [new TextRun({ text: "University of Hilla, Babil, Iraq", italics: true, size: 20, font: FONT })],
});
const authorNote = new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 300 },
  children: [new TextRun({ text: "Corresponding author email and ORCID iD: to be supplied by the author prior to submission.", italics: true, size: 17, font: FONT, color: "8a2e2e" })],
});

const abstractHeading = new Paragraph({
  spacing: { before: 120, after: 100 },
  children: [new TextRun({ text: "Abstract", bold: true, size: 24, font: FONT })],
});
const abstractText = P([bodyRun(
  "Retrieval-augmented systems for legal corpora face two compounding problems: citation graphs approaching hundreds of millions of edges, and retrieved passages that may no longer be good law after a case is overruled or a statute amended. We present UMA-GraphRAG, a multi-agent retrieval framework that shards a temporal legal citation graph across agents, each estimating its own uncertainty via a self-assessed ensemble, and fuses agent beliefs through a protocol that prunes candidates by an adaptive uncertainty quantile and re-ranks survivors by precision-weighted fusion; every candidate is filtered by an explicit temporal-validity predicate before ranking. We built a synthetic temporal legal citation benchmark scaling to 1,000,000 documents and 6,006,226 edges, evaluated against a real tuned centralized HNSW-ANN index in addition to brute-force and ablated baselines. The result is not favorable to decentralization at the scales we can test: HNSW-ANN reaches perfect recall at roughly 300 times less work than our method, at every scale tested, so we do not claim a performance advantage over centralized search and instead motivate decentralization by necessity rather than speed. Within the decentralized family, an eight-seed statistical comparison shows uncertainty-weighted fusion beats uniform fusion with a large effect size (Cohen's d = 1.18, p = 0.0074), well-calibrated to realized error (Spearman ρ up to 0.86), though the advantage is regime-dependent and reverses under extreme agent unreliability. A semantic-only baseline that ignores temporal validity returns law that is no longer good law in 30.6% of its top-10 results; every validity-aware variant, including ours, avoids this by construction, and a metadata-noise ablation shows the mechanism degrades gracefully rather than being an artifact of perfect synthetic labels. Recall degrades with both corpus size and shard count, and additional communication rounds do not improve it. We report all of this directly, including a citation correction, an algorithm/prose inconsistency fix, and a provenance-aware fusion variant added specifically to test whether double-counting explains the rounds finding (it does not)."
)]);

const keywords = P([
  new TextRun({ text: "Keywords: ", bold: true, size: 22, font: FONT }),
  bodyRun("retrieval-augmented generation, graph retrieval, multi-agent systems, uncertainty estimation, legal NLP, temporal knowledge graphs, decentralized systems"),
], { spacing: { after: 320 } });

// ======================= 1. INTRODUCTION =======================
const s1_p1 = P([bodyRun(
  "Legal research increasingly depends on retrieval-augmented generation (RAG) systems that locate relevant statutes, regulations, and judicial opinions before an LLM drafts an answer [1], [2]. Two properties of legal corpora make this harder than the open-domain question answering setting RAG was designed for. First, the corpus is a citation graph, not a bag of independent passages: cases cite cases, statutes amend statutes, and a query about \"the current standard for X\" implicitly asks about a specific position in that graph's history. Second, the graph is temporal in a way that carries legal consequences. A citation that was authoritative in 2005 may have been overruled in 2019; a passage that reads as good law in isolation may no longer be citable at all. Graph-based RAG variants have shown that indexing a corpus as a graph rather than a flat passage store improves multi-hop and corpus-level questions [3]–[7], and legal NLP has produced strong domain-specific encoders and benchmarks [8]–[12]. Neither line of work, to our knowledge, addresses the two problems jointly: retrieving from a citation graph whose size approaches national case-law scale while continuously respecting which parts of that graph are still valid law as of the query date."
)]);
const s1_p2 = P([bodyRun(
  "A second obstacle is architectural. A single centralized index that scores every candidate document against every query does not scale gracefully as a corpus grows toward the size of a national or multi-jurisdictional case-law archive — plausibly billions of documents connected by an even larger number of citation edges. Sharding the index across machines is the obvious remedy, but sharding introduces a new problem: no single shard sees the whole graph, so the system must reconcile partial, and in practice unequally reliable, local views of relevance before it can rank anything. We treat this reconciliation problem as fundamentally an uncertainty quantification problem — each agent's local estimate of a document's relevance carries a different amount of noise depending on how much of the graph it can see and how faithfully it can score candidates, and the fusion procedure that combines agents' estimates should account for that."
)]);
const s1_p3 = P([bodyRun(
  "We propose UMA-GraphRAG, a multi-agent retrieval framework in which each agent holds a shard of a temporal legal citation graph, prunes its local search using a coarse, uncertainty-adaptive practice-area index, scores surviving candidates while enforcing a temporal-validity predicate, and estimates its own confidence with a lightweight self-assessed ensemble. Agents exchange candidates over a sparse, decentralized gossip topology, using each candidate's inverse uncertainty as a fusion weight — the same precision-weighting principle used to combine independent noisy measurements in classical meta-analysis — and prune the exchange itself by an uncertainty quantile that tightens across communication rounds. We evaluate the design honestly rather than only favorably: alongside the conditions under which it helps, we report the conditions under which its central mechanism provides no measurable benefit, or even a net cost, because we believe that is more useful to a reader deciding whether to build on this design than a uniformly positive result would be."
)]);

const s1_contrib_lead = P([bodyRun("This paper makes the following contributions:")], { spacing: { after: 80 } });

const contribItems = [
  "We introduce UMA-GraphRAG, a multi-agent retrieval architecture for temporal legal corpora that combines replicated hash-sharding, a sparse small-world topology for its communication rounds, two-tier uncertainty use (coarse practice-area pruning and fine-grained inverse-variance fusion), and an explicit temporal-validity predicate applied before ranking, and we state precisely which parts of the protocol are genuinely peer-to-peer and which (its final cross-agent aggregation step) are a centralized reduction.",
  "We benchmark the method against a real, tuned, centralized approximate-nearest-neighbor index (HNSW) rather than only against brute-force search, and report the result plainly: HNSW-ANN reaches perfect recall at roughly 300 times less work than our method at every scale we tested, so we do not claim a performance case for decentralization and instead motivate it by necessity — data that cannot be centralized, or scale beyond a single machine's capacity, neither of which we test here.",
  "We give a precision-weighted (inverse-uncertainty) fusion rule with an adaptive quantile-based pruning schedule, and establish its behavior with adequate statistical power: an eight-seed comparison (up from three in an earlier draft, which was underpowered and gave an inconclusive result) shows a statistically significant, large-effect-size recall advantage over uniform-weighted fusion (Cohen's d = 1.18, p = 0.0074), and a dedicated calibration analysis confirms the self-assessed uncertainty it depends on correlates strongly with realized error (Spearman ρ up to 0.86).",
  "We show that temporal-validity-aware scoring is not a cosmetic addition: a semantic-only retrieval baseline that ranks purely by embedding similarity returns documents that are no longer good law in 30.6% of its top-10 results, while every validity-aware method reaches 100% validity precision by construction — and we go further than construction by testing the gate against deliberately corrupted supersession metadata, showing it degrades gracefully rather than being an artifact of perfect synthetic labels.",
  "We build and release a synthetic temporal legal citation graph generator and a full benchmarking harness scaling to 1,000,000 documents and 6,006,226 edges, and use it to characterize the method's actual scaling behavior — an approximately constant 41% reduction in per-query work relative to brute-force search, not sub-linear complexity — together with recall that degrades as corpus size and shard count grow.",
  "We report several negative or corrective findings we did not retune away: additional communication rounds reduce recall in this benchmark, and a provenance-tracked fusion variant designed to test whether duplicate relayed observations explain that finding shows they do not; the uncertainty-weighting advantage reverses sign at extreme agent unreliability; and — corrected in this revision after external review — an equation-numbering inconsistency, an algorithm/prose mismatch regarding when the validity gate is applied, and a citation that had mischaracterized the CaseHOLD dataset as an overruling-detection task.",
];
const contribParas = contribItems.map((t, i) => new Paragraph({
  numbering: { reference: "contrib-list", level: 0 },
  spacing: { after: 140, line: 276 },
  alignment: AlignmentType.JUSTIFIED,
  children: [bodyRun(t)],
}));

const s1_roadmap = P([bodyRun(
  "Section 2 positions this work against graph-RAG, legal NLP, multi-agent LLM, and uncertainty-estimation literatures, including several 2025–2026 papers added in this revision. Section 3 describes the method and its two uncertainty mechanisms in detail, with complexity analysis and an explicit account of which parts of the protocol are and are not decentralized. Section 4 describes the synthetic benchmark, baselines — including the tuned HNSW-ANN index — and metrics. Section 5 reports results across seven subsections: the main comparison, the validity gate under corrupted metadata, scaling behavior, reliability heterogeneity, communication rounds and provenance-aware fusion, uncertainty calibration, and a discussion of what the trillion-scale motivation actually requires. Section 6 concludes with limitations, future work, and data/code availability and responsible-use declarations."
)]);

module.exports = { title, authors, affil, authorNote, abstractHeading, abstractText, keywords, s1_p1, s1_p2, s1_p3, s1_contrib_lead, contribParas, s1_roadmap };
