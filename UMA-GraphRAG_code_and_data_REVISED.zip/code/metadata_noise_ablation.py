"""
metadata_noise_ablation.py
Tests the temporal-validity gate under imperfect ("citator-realistic") metadata
rather than only against its own perfect ground truth. The system makes its
valid/invalid ranking decisions using a NOISY view of the supersession record
(missing and falsely-flagged entries); we then score its output against the
TRUE (uncorrupted) supersession record to see whether output quality degrades
gracefully as metadata quality degrades, directly addressing the concern that
100% validity precision is tautological under perfect synthetic metadata.
"""
import csv
import numpy as np
from graph_gen import generate_temporal_legal_graph, is_valid_at, noisy_superseded_by

OUT = "/home/claude/uma_graphrag/data"


def run_query_full_noisy(graph, all_ids, query_vec, query_time, sup_noisy, k=10):
    sims = graph["embeddings"][all_ids] @ query_vec
    valid = is_valid_at(graph, all_ids, query_time, superseded_by_override=sup_noisy)
    sims = np.where(valid, sims, -1e9)
    top_idx = np.argpartition(-sims, k)[:k]
    top_idx = top_idx[np.argsort(-sims[top_idx])]
    return [int(all_ids[i]) for i in top_idx]


def true_validity_precision(graph, pred_ids, query_time):
    if len(pred_ids) == 0:
        return np.nan
    valid = is_valid_at(graph, np.array(pred_ids, dtype=np.int64), query_time)  # TRUE metadata
    return float(valid.mean())


def oracle_topk_true(graph, all_ids, query_vec, query_time, k=10):
    sims = graph["embeddings"][all_ids] @ query_vec
    valid = is_valid_at(graph, all_ids, query_time)  # TRUE metadata oracle
    sims = np.where(valid, sims, -1e9)
    top_idx = np.argpartition(-sims, k)[:k]
    top_idx = top_idx[np.argsort(-sims[top_idx])]
    return set(int(all_ids[i]) for i in top_idx)


def recall_vs_true_oracle(pred_ids, oracle_set):
    if len(oracle_set) == 0:
        return np.nan
    return len(set(pred_ids) & oracle_set) / len(oracle_set)


def main():
    n = 100000
    g = generate_temporal_legal_graph(n, seed=1)
    all_ids = np.arange(n)
    rng = np.random.default_rng(777)
    n_q = 150
    queries = []
    for _ in range(n_q):
        t_topic = rng.integers(0, g["topic_centers"].shape[0])
        qv = g["topic_centers"][t_topic] + rng.normal(scale=0.3, size=g["embeddings"].shape[1])
        qv = qv / np.linalg.norm(qv)
        qt = int(rng.integers(int(0.4 * n), n))
        queries.append((qv.astype(np.float32), qt))

    noise_settings = [
        (0.0, 0.0), (0.1, 0.0), (0.3, 0.0), (0.5, 0.0), (0.8, 0.0),
        (0.0, 0.01), (0.0, 0.05), (0.0, 0.15),
        (0.3, 0.05), (0.5, 0.1),
    ]
    rows = []
    for p_missing, p_false in noise_settings:
        sup_noisy = noisy_superseded_by(g, seed=1, p_missing=p_missing, p_false=p_false)
        precisions = []
        recalls = []
        for qv, qt in queries:
            pred = run_query_full_noisy(g, all_ids, qv, qt, sup_noisy)
            precisions.append(true_validity_precision(g, pred, qt))
            oracle = oracle_topk_true(g, all_ids, qv, qt)
            recalls.append(recall_vs_true_oracle(pred, oracle))
        n_overruled_recorded = int((sup_noisy >= 0).sum())
        n_overruled_true = int((g["superseded_by"] >= 0).sum())
        rows.append(dict(
            p_missing=p_missing, p_false=p_false,
            n_overruled_recorded=n_overruled_recorded, n_overruled_true=n_overruled_true,
            true_validity_precision=float(np.nanmean(precisions)),
            true_validity_precision_std=float(np.nanstd(precisions)),
            recall_vs_true_oracle=float(np.nanmean(recalls)),
            recall_vs_true_oracle_std=float(np.nanstd(recalls)),
        ))
        print(f"p_missing={p_missing} p_false={p_false} -> true validity precision = {np.nanmean(precisions):.4f}, "
              f"recall vs true oracle = {np.nanmean(recalls):.4f}")

    with open(f"{OUT}/metadata_noise_ablation.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    main()
