const H = require("./docx_helpers.js");
const { Table, TableRow, TableCell, WidthType, AlignmentType,
  FONT, bodyRun, P, H2, Caption, CenterImg, TCell } = H;

const mkRow = (cells, header = false) => new TableRow({
  children: cells.map((c) => TCell(c, { bold: header, shade: header })),
});
const mkRowBold = (cells, boldMask) => new TableRow({
  children: cells.map((c, i) => TCell(c, { bold: !!boldMask[i] })),
});

// ============================= 5.1 Main Comparison =============================
const h51 = H2("Main Comparison", "5.1");
const s51a = P([bodyRun(
  "Table 3 reports recall, validity precision, and work units at N = 100,000 (K = 25), averaged over eight independently generated corpora and shardings (seeds), each with 150 queries — an increase from the three seeds used in an earlier draft of this study, made specifically to give the cross-seed comparison in this section enough statistical power to be trustworthy (an earlier draft had reported this comparison as inconclusive with only three seeds; it is not with eight, as discussed below). We also add a real, tuned, centralized approximate-nearest-neighbor baseline, HNSW-ANN (hnswlib, cosine space, M = 16, ef_construction = 200, ef_search = 80, over-fetching 200 candidates per query and then applying the same temporal-validity gate as every other method), because comparing only against an untuned exact brute-force baseline understates what a production centralized system would actually cost."
)]);
const s51b = P([bodyRun(
  "The result is not flattering to the proposed architecture, and we report it exactly as measured. HNSW-ANN reaches 100.0% recall — statistically indistinguishable from exact brute-force search at this operating point — at 200 work units per query and sub-millisecond wall-clock latency (Section 5.3), roughly 300 times less work than UMA-GraphRAG's 61,401 work units for a method that only reaches 51.9% recall. StaticPruneRAG, a single trusted agent doing nothing but coarse practice-area pruning, beats both decentralized methods on recall (89.2%) at roughly a fifth of their work. Put plainly: at every scale we tested, a standard, off-the-shelf, single-machine ANN index dominates our proposed decentralized protocol on both accuracy and efficiency simultaneously. We discuss in Section 5.7 what this means for the paper's motivation — in short, the case for a decentralized architecture at the scales we can test here has to rest on necessity (data that cannot be centralized, fault tolerance, or true single-machine capacity limits we did not reach) rather than on it being faster or more accurate than centralized search, and we no longer frame the contribution as a performance win over centralized retrieval."
)]);
const s51c = P([bodyRun(
  "Within the decentralized family, the comparison the paper's core mechanism is actually about — UMA-GraphRAG's uncertainty-weighted fusion against MultiAgentUniform's unweighted fusion, both given identical sharding, topology, and noisy observations — is now clearly resolved with the larger seed count. Mean recall is 51.9% ± 6.0% for UMA-GraphRAG versus 46.6% ± 2.1% for MultiAgentUniform; the per-seed gap is positive in 7 of 8 seeds, a paired t-test across seed-level means gives t = 3.72, p = 0.0074, and the effect size is large (Cohen's d = 1.18). This is a materially stronger result than the three-seed comparison reported in an earlier version of this study, which had one negative seed out of three and did not reach significance — that comparison was simply underpowered, not representative of a null effect, and we did not have the statistical power to tell the difference until we ran more seeds. We regard the corrected, adequately-powered comparison in this section as superseding the earlier one."
)]);
const s51d = P([bodyRun(
  "Every validity-aware method reaches exactly 100.0% validity precision, by construction — the temporal-validity gate of Eq. (4) either admits a candidate or it does not, so no valid-only method can return an invalid document regardless of how noisy its similarity ranking is. SemanticOnly, which disables that gate, returns documents that are no longer good law in 30.6% of its top-10 results (validity precision 0.694 ± 0.015), and — as a direct mathematical consequence of restricting a ranking to a subset, since removing lower-ranked invalid competitors can only preserve or improve a valid document's relative rank — its recall against the validity-aware oracle is numerically identical to its validity precision. This remains the paper's cleanest finding: a retrieval system that is otherwise strong on ordinary relevance metrics but temporally naive will confidently hand a user law that has been overruled roughly three times in ten, with no signal to the user that anything is wrong. But a 100% figure earned only against a system's own perfect synthetic metadata proves little on its own; Section 5.2 tests it against metadata the system itself does not fully trust."
)]);

const table3rows = [["Method", "Recall@10 ↑", "Validity prec. ↑", "Work units ↓"]];
const table3data = [
  ["FullGraphRAG", "1.000 ± 0.000", "1.000 ± 0.000", "100,000"],
  ["HNSW-ANN (tuned)", "1.000 ± 0.000", "1.000 ± 0.000", "200"],
  ["StaticPruneRAG", "0.892 ± 0.021", "1.000 ± 0.000", "12,519 ± 4"],
  ["MultiAgentUniform", "0.466 ± 0.021", "1.000 ± 0.000", "59,526 ± 2,650"],
  ["UMA-GraphRAG (proposed)", "0.519 ± 0.060", "1.000 ± 0.000", "61,401 ± 2,650"],
  ["SemanticOnly (no validity gate)", "0.694 ± 0.015", "0.694 ± 0.015", "100,000"],
];
const boldMasks = [
  [false, true, true, false],
  [false, true, true, true],
  [false, false, true, false],
  [false, false, true, false],
  [false, false, true, false],
  [false, false, false, false],
];
const table3 = new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  rows: [mkRow(table3rows[0], true), ...table3data.map((r, i) => mkRowBold(r, boldMasks[i]))],
});
const cap3 = Caption("Table 3. Main comparison at N = 100,000, K = 25. Recall and validity precision are the mean ± standard deviation of the per-seed means across 8 independently generated corpus/sharding realizations (1,200 queries total); work units are averaged the same way. Bold marks the best value per column. HNSW-ANN and FullGraphRAG top every column simultaneously only because neither is a scalability-constrained method at this corpus size (Section 5.1); among the genuinely decentralized methods, UMA-GraphRAG has the better recall and worse work than MultiAgentUniform.");
const fig5 = CenterImg("fig5_main_bars.png", 6.2);
const fig5cap = Caption("Fig. 2. Recall and validity precision by method (mean ± std over 8 seeds). HNSW-ANN matches FullGraphRAG's ceiling at a fraction of the cost (Table 3); UMA-GraphRAG's advantage over MultiAgentUniform is visible but comes with wider cross-seed variance; the validity-precision gap for SemanticOnly is large and consistent.");

// ============================= 5.2 Validity gate under noisy metadata =============================
const h52 = H2("The Validity Gate Under Imperfect Metadata", "5.2");
const s52a = P([bodyRun(
  "The 100% validity precision in Table 3 is trivially true whenever a system's validity decisions are scored against the same perfect metadata it used to make them — it says nothing about whether the mechanism is useful when the underlying citator-style metadata is itself incomplete or wrong, which any real deployment must assume. We tested this directly rather than leaving it as an assumption: using the same N = 100,000 corpus, we constructed a noisy view of the supersession record in which a fraction p_missing of genuine supersessions are hidden from the system (it believes an overruled document is still good law) and a fraction p_false of non-superseded documents are incorrectly flagged as superseded (it believes a valid document has been overruled). The system makes its ranking decisions using only this noisy view; we then score its output against the true, uncorrupted record."
)]);
const s52b = P([bodyRun(
  "Figure 3 shows the result is asymmetric and, we think, informative rather than merely reassuring. Missing supersession records barely move true validity precision — even hiding 80% of genuine supersessions drops precision only from 1.000 to 0.994 — because our synthetic corpus's underlying overrule rate is a realistic-but-low 1.5%, so most candidates were never at risk of misclassification in the first place; the gate's protection scales with how much of a jurisdiction's case law has actually been overruled, and is bounded above by that base rate. False-positive supersession flags tell a different and more actionable story: they leave validity precision unchanged (an incorrectly-excluded document simply never appears, so it cannot lower precision) but measurably reduce recall against the true oracle, from 1.000 at p_false = 0 to 0.922 at p_false = 0.15 — a citator system with a 15% false-positive overrule rate would cause this design to silently omit almost 8% of the controlling authority a query should have returned. This is exactly the omission failure mode that validity precision alone cannot detect, and it is why we report recall against the true oracle alongside it rather than treating precision as sufficient on its own."
)]);
const fig_noise = CenterImg("fig_metadata_noise.png", 6.5);
const fig_noise_cap = Caption("Fig. 3. True validity precision and recall (scored against uncorrupted ground truth) as the system's own metadata is corrupted. (a) Hidden supersessions barely affect precision, bounded by the corpus's 1.5% base overrule rate. (b) False-positive supersession flags leave precision unchanged but measurably suppress recall — an omission failure that a precision-only evaluation would miss entirely.");
const s52c = P([bodyRun(
  "We see this as a partial, not complete, answer to whether the validity mechanism is real-world-useful: it shows the gate degrades gracefully and in an interpretable way rather than collapsing or masking a failure mode, but it still relies on a synthetic corpus with a single supersession pointer per document, and does not model the amendment-versus-overruling-versus-negative-treatment distinctions that determine how a real citator would actually be wrong (Section 6.1)."
)]);

// ============================= 5.3 Scaling Behavior =============================
const h53 = H2("Scaling Behavior", "5.3");
const s53a = P([bodyRun(
  "Figure 4 extends the scaling study from 20,000 to 1,000,000 documents (K = 8 to 250) and now includes HNSW-ANN alongside the four methods evaluated in Section 5.1. Two findings temper the paper's motivating trillion-scale framing, and a third — the addition since the previous version of this study — sharpens that tempering considerably. First, work per query for both decentralized methods tracks a strikingly constant fraction of N across every scale we tested: UMA-GraphRAG's work/N ratio is 0.611, 0.599, 0.591, and 0.588 at N = 20,000 through 1,000,000 — essentially flat, meaning the method delivers a roughly constant-factor (about 41% at the largest scale) reduction in work relative to FullGraphRAG's exactly linear cost, not a change in complexity class. Second, recall for both decentralized methods degrades as the corpus (and shard count) grows: UMA-GraphRAG falls from 68.8% at N = 20,000 to 40.5% at N = 1,000,000, while StaticPruneRAG and FullGraphRAG hold flat or improve over the same range."
)]);
const s53b = P([bodyRun(
  "Third, and most consequentially, HNSW-ANN's work per query is flat at 200 regardless of N — by construction, since approximate graph-based ANN search cost depends on index structure and the fixed fetch budget, not on a linear scan of the corpus — while its recall stays at 1.000 at every scale, and its build time (2.5 s at N = 20,000 to 167 s at N = 1,000,000, single core) is a one-time cost amortized over all subsequent queries. Achieving genuinely sub-linear scaling for our own decentralized method toward a trillion-edge corpus would additionally require the coarse cluster budget C of Eq. (2) to itself shrink as N grows, which our uncertainty-adaptive rule does not currently do — C depends only on the local centroid-similarity gap, not on corpus size. We flag both gaps explicitly: between the method's design intent and what we have demonstrated, and between what a decentralized protocol offers and what a well-understood centralized data structure already provides at every scale we were able to test on a single machine."
)]);
const fig2 = CenterImg("fig2_scaling.png", 6.6);
const fig2cap = Caption("Fig. 4. Scaling behavior from N = 20,000 to N = 1,000,000 (K = 8 to 250, log-x), now including a tuned centralized HNSW-ANN index. (a) HNSW-ANN holds perfect recall at every scale while both decentralized methods degrade. (b) HNSW-ANN's work per query is flat and near the bottom of the plot at every scale; the decentralized methods track a near-constant fraction of FullGraphRAG's linear cost. (c) Communication cost grows with shard count under our K(N) scaling rule.");
const s53c = P([bodyRun(
  "We caution against reading the latency numbers in our result files as representative of real deployment performance for the decentralized methods, for the reasons given in Section 3.4 and Section 5.7: our gossip protocol is simulated sequentially on a single CPU core in reference Python, and Python-level dictionary and message-passing overhead per unit of simulated work is substantially more expensive than either FullGraphRAG's or HNSW-ANN's vectorized/compiled inner loops. HNSW-ANN's wall-clock query latency (0.27 ms at N = 20,000 to 1.0 ms at N = 1,000,000) is measured directly from the same hnswlib C++ implementation a production system would use, so unlike our own method's latency figures, it is a reasonable proxy for real deployment performance, not merely a simulated proxy."
)]);

// ============================= 5.4 Heterogeneity =============================
const h54 = H2("Effect of Agent Reliability Heterogeneity", "5.4");
const s54 = P([bodyRun(
  "Section 5.1's controlled comparison showed uncertainty-weighted fusion beating uniform fusion under our default reliability split (50% of agents at σ = 0.05, 50% at σ = 0.004). Figure 5 sweeps the low-fidelity noise level σ_high from 0.008 to 0.12, holding everything else fixed, to characterize when this holds. At very low heterogeneity (σ_high = 0.008, barely distinguishable from the high-fidelity tier) the two methods are statistically indistinguishable (gap = 0.002) — unsurprising, since there is almost nothing to correctly downweight. The gap grows through σ_high = 0.02 and peaks at σ_high = 0.035 (gap = 0.131, UMA-GraphRAG 79.8% vs. MultiAgentUniform 66.7%), then narrows again at σ_high = 0.05 (our default) and reverses sign at σ_high = 0.08 and 0.12, where MultiAgentUniform outperforms UMA-GraphRAG by 6-8 points. Overall recall for both methods also collapses toward chance level in this high-noise regime (12% and 4% for UMA-GraphRAG at σ_high = 0.08 and 0.12), which is the more consequential fact: neither method retrieves usefully once agent noise is that large, and the sign of a small residual gap between two near-random methods is not something we would want a reader to over-interpret. Section 5.6's calibration analysis shows the self-assessed uncertainty (Eq. 5) tracks realized error well in aggregate (Spearman ρ = 0.69), but a well-calibrated aggregate statistic does not rule out the estimator becoming locally unreliable at the extreme end of the noise range where this reversal occurs; we did not attempt to fix this by retuning the ensemble calibration after seeing the result, since doing so would risk fitting the ablation rather than reporting it."
)]);
const fig3 = CenterImg("fig3_heterogeneity.png", 4.3);
const fig3cap = Caption("Fig. 5. Recall vs. low-fidelity agent noise level σ_high (N = 100,000, K = 25, fixed corpus, 100 queries). The uncertainty-weighting advantage (bars) is largest at moderate heterogeneity and reverses sign at extreme noise, where both methods' recall has already collapsed toward chance.");

// ============================= 5.5 Rounds + provenance =============================
const h55 = H2("Effect of Communication Rounds and Provenance-Aware Fusion", "5.5");
const s55a = P([bodyRun(
  "We swept the communication-round budget R from 0 (no gossip at all — each agent returns only its own local candidates) to 5, at fixed N = 100,000, K = 25, and our default reliability split. Figure 6 shows the result runs counter to the intuition that more consensus rounds should monotonically help: recall for both methods is highest at R = 0 (76.8% for UMA-GraphRAG, 64.1% for MultiAgentUniform) and declines steadily as R increases, reaching 53.6% and 45.1% respectively by R = 5, while message volume grows linearly with R as expected (0 to 500 messages per query). With replication factor 3, a meaningful fraction of the true top-10 for a typical query is already held directly by at least one of the querying agents' immediate shards, so the main service multi-hop gossip provides in this benchmark is discovery of replicas the initiating agent does not hold directly — and once that discovery has happened (empirically, within one round), further rounds mostly propagate additional noisy, relayed estimates that dilute rather than sharpen the fused ranking."
)]);
const s55b = P([bodyRun(
  "One plausible explanation is that the precision-weighted fusion rule (Eq. 6–8), applied naively over a loopy gossip topology, double-counts relayed copies of the same original observation as if they were independent new evidence, silently inflating confidence in a way that would compound with each additional round. We tested this directly by implementing a provenance-tracked variant that tags every estimate with the identity of its originating agent and only fuses a relayed message when it carries at least one originating agent not already reflected in the receiving pool, discarding pure relays entirely rather than re-fusing them. Figure 6 shows this materially changes neither the recall level at any round budget nor the finding that additional rounds reduce recall (at R = 5, 52.0% for the provenance-aware variant versus 53.6% for the base protocol — closer to, not better than, MultiAgentUniform's 45.1%). Double-counting of relayed duplicates is therefore not the primary driver of the rounds-hurt-recall finding in this benchmark; the more likely explanation is that later rounds increasingly incorporate genuinely new, but increasingly noisy and distant, relayed estimates from low-fidelity agents that a purely local, low-round-count answer would not have been exposed to at all. We nonetheless consider provenance tracking a correctness property the base protocol should have independent of whether it changes this particular result, since a fusion rule justified by an independence assumption (Section 3.4) should not silently violate it."
)]);
const fig_prov = CenterImg("fig_provenance.png", 4.3);
const fig_prov_cap = Caption("Fig. 6. Recall vs. communication round budget R, comparing the base protocol against a provenance-aware variant that discards duplicate relays. The two nearly overlap, ruling out double-counting as the primary explanation for why additional rounds reduce recall.");
const s55c = P([bodyRun(
  "UMA-GraphRAG outperforms MultiAgentUniform at every round budget we tested, which is a more consistent result than the cross-seed comparison in isolation, but the practical implication is that our default configuration (R = 3, chosen a priori for headroom before we ran this ablation) is not recall-optimal on this benchmark; we report the R = 3 results throughout the rest of the paper as originally configured rather than substituting the ablation-optimal R = 0 or R = 1 after the fact, since doing so would be exactly the kind of post-hoc retuning we are trying to avoid. A round budget that adapts to when discovery has actually converged, rather than a fixed R, is a natural next step (Section 6.2)."
)]);

// ============================= 5.6 Calibration =============================
const h56 = H2("Uncertainty Calibration", "5.6");
const s56a = P([bodyRun(
  "The fusion and pruning mechanisms in Section 3 assume that self-assessed uncertainty (Eq. 5) is actually informative about an agent's realized scoring error, not merely a plausible-looking proxy. We tested this assumption directly rather than only relying on it: for 37,500 (agent, candidate, query) observations drawn from the N = 100,000 benchmark, we recorded each agent's noisy local score, its self-assessed uncertainty, and the true noiseless cosine similarity it was trying to estimate. Self-assessed uncertainty correlates strongly and monotonically with realized squared error (Spearman ρ = 0.687, p < 10⁻³⁰⁰) and with the agent's true (but not directly observed by the agent) noise level σ_a (Spearman ρ = 0.860, p < 10⁻³⁰⁰). Figure 7 bins observations by self-assessed uncertainty and plots the realized RMSE per bin: RMSE rises from about 0.004 in the lowest-uncertainty bins to about 0.063 in the highest, with a visible saturation among the top four bins, consistent with those bins being dominated by the fixed σ_high = 0.05 tier of agents rather than a continuum of noise levels."
)]);
const s56b = P([bodyRun(
  "This is a genuinely positive result for the mechanism's internal validity — the self-assessment is not decorative — but it is an aggregate statistic over many agents and queries, and Section 5.4's reversal at extreme heterogeneity shows that good aggregate calibration does not guarantee the estimator remains reliable in every operating regime the fusion rule might encounter."
)]);
const fig_calib = CenterImg("fig_calibration.png", 4.4);
const fig_calib_cap = Caption("Fig. 7. Realized RMSE of the local noisy score, binned by self-assessed uncertainty (log x-axis). Monotonically increasing, confirming the self-assessment tracks real error rather than being an uninformative proxy, with saturation reflecting the two-tier noise distribution used in this benchmark.");

// ============================= 5.7 Discussion =============================
const h57 = H2("Discussion: What the Trillion-Scale Motivation Requires", "5.7");
const s57 = P([bodyRun(
  "The framing that motivated this paper is that a decentralized, uncertainty-guided pruning protocol should make trillion-edge legal corpus analysis tractable. Section 5.1's HNSW-ANN result requires us to state plainly what we have and have not shown. We have not shown that decentralization is faster or more accurate than centralized search at any scale we tested — the opposite is true, decisively, and a reader should not come away from this paper believing otherwise. What we have shown is narrower: (i) a constant-factor, not asymptotic, reduction in per-query work relative to centralized brute-force search, which is no longer a meaningful comparison once a tuned ANN index is available; (ii) genuine horizontal parallelizability across agents that our sequential single-core simulation cannot itself demonstrate as a wall-clock speedup; (iii) recall that degrades, not holds steady, as the system is scaled toward the shard counts a trillion-edge deployment would require; (iv) a communication cost that grows linearly with shard count; and (v) a temporal-validity mechanism that degrades gracefully, not catastrophically, under imperfect metadata, and is architecturally orthogonal to whether the underlying index is centralized or decentralized — it could be attached to HNSW-ANN just as easily as to our protocol, and Table 3's validity-precision column would look identical if it were. The honest motivating case for a decentralized architecture at all is therefore not performance at the scales we can test; it is scenarios where centralization is not an option — data that cannot legally or technically be pooled onto one index across jurisdictions or institutions, fault-tolerance requirements that rule out a single point of failure, or corpus sizes that genuinely exceed what a single machine's memory can hold, which a single HNSW index handling one million documents on a single CPU core in this study does not come close to testing. We did not have the infrastructure to test that regime, and we say so directly in Section 6.1 rather than implying the results here speak to it."
)]);

module.exports = {
  h51, s51a, s51b, s51c, s51d, table3, cap3, fig5, fig5cap,
  h52, s52a, s52b, fig_noise, fig_noise_cap, s52c,
  h53, s53a, s53b, fig2, fig2cap, s53c,
  h54, s54, fig3, fig3cap,
  h55, s55a, s55b, fig_prov, fig_prov_cap, s55c,
  h56, s56a, s56b, fig_calib, fig_calib_cap,
  h57, s57,
};
