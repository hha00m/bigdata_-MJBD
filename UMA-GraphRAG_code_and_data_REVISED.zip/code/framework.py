"""
framework.py
UMA-GraphRAG: Uncertainty-Weighted Multi-Agent GraphRAG.

Implements the proposed method and three baselines (FullGraphRAG,
StaticPruneRAG, MultiAgentUniform) plus a temporal-validity-blind
SemanticOnly reference used only for the validity-precision comparison.

Two distinct uncertainty signals are used, matching the two mechanisms in
the paper:
  1. Coarse (topic-cluster) uncertainty drives DYNAMIC GRAPH PRUNING: how
     many practice-area clusters an agent must fully score before it can be
     confident it has not missed the true top-k.
  2. Fine (ensemble-disagreement) uncertainty drives RE-RANKING: candidates
     are fused across agents in inverse proportion to their score variance,
     i.e. precision-weighted (inverse-variance) fusion, the classical
     approach to combining noisy estimates from independent sources.
"""
import time
import numpy as np
import networkx as nx

from graph_gen import is_valid_at

RNG_ENSEMBLE_HEADS = 5


def partition_agents(n_nodes, n_agents, replication=2, seed=0):
    """Hash-based (load-balanced) sharding with light replication: each
    document is independently assigned to `replication` distinct shards,
    mirroring the redundant sharding real distributed vector stores use for
    fault tolerance. Replication is what creates genuine opportunities for
    cross-agent fusion (two agents independently holding, and independently
    estimating, the same document)."""
    rng = np.random.default_rng(seed + 777)
    replication = min(replication, n_agents)
    assign = np.stack(
        [rng.choice(n_agents, size=n_nodes, replace=True) for _ in range(replication)], axis=1
    )
    # ensure the r copies of a doc go to distinct agents where possible
    for i in range(n_nodes):
        seen = set()
        for r in range(replication):
            while assign[i, r] in seen:
                assign[i, r] = rng.integers(0, n_agents)
            seen.add(assign[i, r])
    shards = [np.sort(np.unique(assign[:, r][assign[:, r] == a])) for a in range(n_agents) for r in [0]]
    # rebuild properly: for each agent, collect all doc ids assigned to it in any replica slot
    shards = []
    flat_doc = np.repeat(np.arange(n_nodes), replication)
    flat_agent = assign.reshape(-1)
    order = np.argsort(flat_agent, kind="stable")
    flat_agent_sorted = flat_agent[order]
    flat_doc_sorted = flat_doc[order]
    bounds = np.searchsorted(flat_agent_sorted, np.arange(n_agents + 1))
    for a in range(n_agents):
        shards.append(flat_doc_sorted[bounds[a]:bounds[a + 1]].astype(np.int32))
    return shards


def agent_reliability(n_agents, low_fidelity_frac=0.35, sigma_low=0.006, sigma_high=0.035, seed=0):
    """Heterogeneous per-agent noise level, modeling a decentralized network
    where some nodes run full-precision indices and others run compressed /
    stale / resource-constrained (edge) indices. Returns sigma_a, the
    standard deviation of each agent's local scoring error."""
    rng = np.random.default_rng(seed + 999)
    is_low = rng.random(n_agents) < low_fidelity_frac
    sigma = np.where(is_low, sigma_high, sigma_low).astype(np.float32)
    return sigma


def comm_graph(n_agents, degree=4, rewire_p=0.1, seed=0):
    if n_agents <= degree + 1:
        return nx.complete_graph(n_agents)
    return nx.connected_watts_strogatz_graph(n_agents, k=degree, p=rewire_p, seed=seed)


def ensemble_heads(dim, seed=0, n_heads=RNG_ENSEMBLE_HEADS, noise_scale=0.12):
    """A small ensemble of perturbed linear projections used as a cheap proxy
    for epistemic (model) disagreement, in the spirit of deep ensembles /
    MC-dropout uncertainty estimation but at negligible extra compute cost."""
    rng = np.random.default_rng(seed + 4242)
    heads = []
    for _ in range(n_heads):
        proj = np.eye(dim, dtype=np.float32) + rng.normal(scale=noise_scale, size=(dim, dim)).astype(np.float32)
        heads.append(proj)
    return heads


def _coarse_select_topics(topic_centers, query_vec, base_c, adaptive):
    sims = topic_centers @ query_vec
    order = np.argsort(-sims)
    if not adaptive:
        C = base_c
    else:
        top = sims[order]
        gap = float(top[0] - top[1]) if len(top) > 1 else 1.0
        if gap < 0.05:
            C = min(base_c * 3, len(topic_centers))
        elif gap < 0.15:
            C = min(base_c * 2, len(topic_centers))
        else:
            C = base_c
    return set(order[:C].tolist()), len(topic_centers)


def _local_candidates(graph, shard_ids, query_vec, query_time, base_c, adaptive, local_m,
                       sigma_a=0.0, noise_rng=None):
    """One agent's local retrieval pass: coarse cluster pruning, then exact
    scoring only within the surviving clusters, then a validity filter.
    sigma_a > 0 injects agent-specific scoring error, modeling a
    compressed / stale local index rather than a full-precision one."""
    topics_sel, centroid_work = _coarse_select_topics(graph["topic_centers"], query_vec, base_c, adaptive)
    shard_topics = graph["topic_id"][shard_ids]
    mask = np.isin(shard_topics, np.fromiter(topics_sel, dtype=np.int32))
    cand_ids = shard_ids[mask]
    work = centroid_work + len(cand_ids)
    if len(cand_ids) == 0:
        return np.empty(0, dtype=np.int32), np.empty(0, dtype=np.float32), work
    sims = graph["embeddings"][cand_ids] @ query_vec
    if sigma_a > 0 and noise_rng is not None:
        sims = sims + noise_rng.normal(scale=sigma_a, size=sims.shape).astype(np.float32)
    valid = is_valid_at(graph, cand_ids, query_time)
    sims = np.where(valid, sims, -1e9)
    if len(cand_ids) > local_m:
        top_idx = np.argpartition(-sims, local_m)[:local_m]
    else:
        top_idx = np.arange(len(cand_ids))
    keep = cand_ids[top_idx]
    keep_scores = sims[top_idx]
    order = np.argsort(-keep_scores)
    return keep[order], keep_scores[order], work


def _ensemble_uncertainty(graph, cand_ids, query_vec, heads):
    if len(cand_ids) == 0:
        return np.empty(0, dtype=np.float32), 0
    emb = graph["embeddings"][cand_ids]
    head_scores = np.stack([emb @ (h @ query_vec) for h in heads], axis=0)  # (M, m)
    u = head_scores.var(axis=0)
    work = len(heads) * len(cand_ids)
    return u.astype(np.float32), work


def _ensemble_uncertainty_selfassessed(graph, cand_ids, query_vec, sigma_a, seed, n_heads=RNG_ENSEMBLE_HEADS):
    """Each agent estimates its own confidence with a small local ensemble
    whose perturbation scale is calibrated to that agent's known index
    fidelity -- e.g. a compressed shard's serving stack knows it is running
    a compressed index and reports wider disagreement accordingly."""
    heads = ensemble_heads(graph["embeddings"].shape[1], seed=seed, n_heads=n_heads,
                            noise_scale=max(sigma_a, 1e-3) * 1.5)
    return _ensemble_uncertainty(graph, cand_ids, query_vec, heads)


def run_query_uma(graph, shards, cg, query_vec, query_time, sigma, query_seed,
                   base_c=3, local_m=40, rounds=3, pool_cap=60, k=10, eps=1e-4):
    """Proposed method: uncertainty-weighted multi-agent decentralized
    retrieval with adaptive graph pruning and inverse-uncertainty re-ranking.
    `sigma` gives each agent's local index noise level; `query_seed` fixes
    the noise realization so this can be compared head-to-head against the
    uniform-fusion ablation on identical noisy observations."""
    work_units = 0
    n_msgs = 0
    msg_bytes = 0
    agent_pool = {}  # agent -> dict(doc_id -> (score, uncertainty))

    for a, ids in enumerate(shards):
        noise_rng = np.random.default_rng(query_seed * 100003 + a)
        cand, sims, w = _local_candidates(graph, ids, query_vec, query_time, base_c, True, local_m,
                                           sigma_a=sigma[a], noise_rng=noise_rng)
        work_units += w
        u, w2 = _ensemble_uncertainty_selfassessed(graph, cand, query_vec, sigma[a], seed=query_seed * 7 + a)
        work_units += w2
        agent_pool[a] = {int(d): (float(s), float(uu) + eps) for d, s, uu in zip(cand, sims, u)}

    for r in range(rounds):
        # adaptive quantile threshold: keep the (1 - r/rounds) least-uncertain
        # fraction of each agent's pool before broadcasting -- this IS the
        # dynamic graph pruning step, tightening every round.
        keep_frac = max(0.3, 1.0 - r / rounds)
        outgoing = {}
        for a, pool in agent_pool.items():
            if len(pool) == 0:
                outgoing[a] = {}
                continue
            items = list(pool.items())
            uncerts = np.array([v[1] for _, v in items])
            thresh = np.quantile(uncerts, keep_frac) if len(uncerts) > 1 else uncerts[0]
            outgoing[a] = {d: v for (d, v) in items if v[1] <= thresh}

        new_pool = {a: dict(agent_pool[a]) for a in agent_pool}
        for a in cg.nodes():
            for b in cg.neighbors(a):
                msg = outgoing[b]
                n_msgs += 1
                msg_bytes += len(msg) * 12  # doc_id(4) + score(4) + uncertainty(4)
                for d, (s_b, u_b) in msg.items():
                    if d in new_pool[a]:
                        s_a, u_a = new_pool[a][d]
                        w_a, w_b = 1.0 / u_a, 1.0 / u_b
                        fused_s = (w_a * s_a + w_b * s_b) / (w_a + w_b)
                        fused_u = 1.0 / (w_a + w_b)
                        new_pool[a][d] = (fused_s, fused_u)
                    else:
                        new_pool[a][d] = (s_b, u_b)
        # bound pool size (re-ranking step: keep top pool_cap by fused score)
        for a in new_pool:
            if len(new_pool[a]) > pool_cap:
                items = sorted(new_pool[a].items(), key=lambda kv: -kv[1][0])[:pool_cap]
                new_pool[a] = dict(items)
        agent_pool = new_pool

    # final aggregation: properly precision-weight every agent's surviving
    # local estimate of a document rather than taking an arbitrary max, so
    # the benefit of inverse-uncertainty weighting is not thrown away at
    # the last step.
    merged = {}
    for a, pool in agent_pool.items():
        for d, (s, u) in pool.items():
            if d not in merged:
                merged[d] = (s, u)
            else:
                s_a, u_a = merged[d]
                w_a, w_b = 1.0 / u_a, 1.0 / u
                merged[d] = ((w_a * s_a + w_b * s) / (w_a + w_b), 1.0 / (w_a + w_b))
    ranked = sorted(merged.items(), key=lambda kv: -kv[1][0])[:k]
    top_ids = [d for d, _ in ranked]
    return dict(top_ids=top_ids, work=work_units, msgs=n_msgs, msg_bytes=msg_bytes)


def run_query_multiagent_uniform(graph, shards, cg, query_vec, query_time, sigma, query_seed,
                                  base_c=3, local_m=40, rounds=3, pool_cap=60, k=10):
    """Ablation: same decentralized topology, same coarse pruning budget, and
    the identical noisy local observations as run_query_uma (same sigma and
    query_seed), but fusion is an unweighted average and pruning uses a
    fixed drop-half rule instead of an uncertainty-adaptive quantile. This
    isolates the effect of uncertainty-awareness itself."""
    work_units = 0
    n_msgs = 0
    msg_bytes = 0
    agent_pool = {}
    for a, ids in enumerate(shards):
        noise_rng = np.random.default_rng(query_seed * 100003 + a)
        cand, sims, w = _local_candidates(graph, ids, query_vec, query_time, base_c, True, local_m,
                                           sigma_a=sigma[a], noise_rng=noise_rng)
        work_units += w
        agent_pool[a] = {int(d): float(s) for d, s in zip(cand, sims)}

    for r in range(rounds):
        outgoing = {}
        for a, pool in agent_pool.items():
            items = sorted(pool.items(), key=lambda kv: -kv[1])
            outgoing[a] = dict(items[: max(1, len(items) // 2)])
        new_pool = {a: dict(agent_pool[a]) for a in agent_pool}
        for a in cg.nodes():
            for b in cg.neighbors(a):
                msg = outgoing[b]
                n_msgs += 1
                msg_bytes += len(msg) * 8  # doc_id(4) + score(4), no uncertainty field
                for d, s_b in msg.items():
                    if d in new_pool[a]:
                        new_pool[a][d] = 0.5 * new_pool[a][d] + 0.5 * s_b
                    else:
                        new_pool[a][d] = s_b
        for a in new_pool:
            if len(new_pool[a]) > pool_cap:
                items = sorted(new_pool[a].items(), key=lambda kv: -kv[1])[:pool_cap]
                new_pool[a] = dict(items)
        agent_pool = new_pool

    # final aggregation: unweighted mean across every agent's surviving local
    # estimate of a document (the direct counterpart of the precision-weighted
    # aggregation used in run_query_uma).
    merged_sum = {}
    merged_cnt = {}
    for a, pool in agent_pool.items():
        for d, s in pool.items():
            merged_sum[d] = merged_sum.get(d, 0.0) + s
            merged_cnt[d] = merged_cnt.get(d, 0) + 1
    merged = {d: merged_sum[d] / merged_cnt[d] for d in merged_sum}
    ranked = sorted(merged.items(), key=lambda kv: -kv[1])[:k]
    return dict(top_ids=[d for d, _ in ranked], work=work_units, msgs=n_msgs, msg_bytes=msg_bytes)


def run_query_static_prune(graph, all_ids, query_vec, query_time, base_c=3, k=10):
    """Ablation: single agent, fixed (non-adaptive) topic-cluster pruning,
    no communication, no uncertainty weighting."""
    cand, sims, work = _local_candidates(graph, all_ids, query_vec, query_time, base_c, False, k)
    order = np.argsort(-sims)[:k]
    return dict(top_ids=[int(cand[i]) for i in order], work=work, msgs=0, msg_bytes=0)


def run_query_full(graph, all_ids, query_vec, query_time, k=10, validity_aware=True):
    """Centralized brute-force baseline: score every document in the corpus."""
    sims = graph["embeddings"][all_ids] @ query_vec
    if validity_aware:
        valid = is_valid_at(graph, all_ids, query_time)
        sims = np.where(valid, sims, -1e9)
    top_idx = np.argpartition(-sims, k)[:k]
    top_idx = top_idx[np.argsort(-sims[top_idx])]
    return dict(top_ids=[int(all_ids[i]) for i in top_idx], work=len(all_ids), msgs=0, msg_bytes=0)


def run_query_hnsw(graph, hnsw_index, query_vec, query_time, k=10, fetch=200):
    """Centralized, production-realistic baseline: a single tuned HNSW ANN
    index (hnswlib) over the full corpus, with the standard over-fetch-then-
    filter pattern for enforcing the temporal-validity predicate (ANN
    indices do not support arbitrary predicate pre-filtering natively)."""
    labels, _ = hnsw_index.knn_query(query_vec, k=min(fetch, hnsw_index.get_current_count()))
    cand_ids = labels[0].astype(np.int64)
    valid = is_valid_at(graph, cand_ids, query_time)
    valid_ids = cand_ids[valid]
    sims = graph["embeddings"][valid_ids] @ query_vec if len(valid_ids) else np.array([])
    if len(valid_ids) > k:
        order = np.argsort(-sims)[:k]
        top_ids = valid_ids[order]
    else:
        top_ids = valid_ids
    return dict(top_ids=[int(i) for i in top_ids], work=fetch, msgs=0, msg_bytes=0)


def oracle_topk(graph, all_ids, query_vec, query_time, k=10):
    sims = graph["embeddings"][all_ids] @ query_vec
    valid = is_valid_at(graph, all_ids, query_time)
    sims = np.where(valid, sims, -1e9)
    top_idx = np.argpartition(-sims, k)[:k]
    top_idx = top_idx[np.argsort(-sims[top_idx])]
    return set(int(all_ids[i]) for i in top_idx)


def recall_at_k(pred_ids, oracle_set):
    if len(oracle_set) == 0:
        return np.nan
    return len(set(pred_ids) & oracle_set) / len(oracle_set)


def validity_precision(graph, pred_ids, query_time):
    if len(pred_ids) == 0:
        return np.nan
    valid = is_valid_at(graph, np.array(pred_ids, dtype=np.int64), query_time)
    return float(valid.mean())


def build_hnsw_index(graph, ef_construction=200, M=16, ef_search=80):
    import hnswlib
    emb = graph["embeddings"]
    N, D = emb.shape
    index = hnswlib.Index(space="cosine", dim=D)
    index.init_index(max_elements=N, ef_construction=ef_construction, M=M)
    index.add_items(emb, np.arange(N))
    index.set_ef(ef_search)
    return index


def run_query_uma_provenance(graph, shards, cg, query_vec, query_time, sigma, query_seed,
                              base_c=3, local_m=40, rounds=3, pool_cap=60, k=10, eps=1e-4):
    """Provenance-aware variant of run_query_uma: every candidate estimate
    carries the ID of the *originating* agent that first observed it, and
    fusion only ever combines estimates that trace back to distinct
    originating agents. A relayed copy of an estimate that has already been
    incorporated (same originating agent) updates the pool's provenance set
    but is never fused a second time, which prevents the double-counting a
    loopy gossip graph would otherwise allow and that a naive precision-
    weighted update (Eq. 4-5) does not itself guard against."""
    work_units = 0
    n_msgs = 0
    msg_bytes = 0
    # pool: doc_id -> (fused_score, fused_uncertainty, frozenset_of_originating_agents)
    agent_pool = {}

    for a, ids in enumerate(shards):
        noise_rng = np.random.default_rng(query_seed * 100003 + a)
        cand, sims, w = _local_candidates(graph, ids, query_vec, query_time, base_c, True, local_m,
                                           sigma_a=sigma[a], noise_rng=noise_rng)
        work_units += w
        u, w2 = _ensemble_uncertainty_selfassessed(graph, cand, query_vec, sigma[a], seed=query_seed * 7 + a)
        work_units += w2
        agent_pool[a] = {int(d): (float(s), float(uu) + eps, frozenset({a})) for d, s, uu in zip(cand, sims, u)}

    for r in range(rounds):
        keep_frac = max(0.3, 1.0 - r / rounds)
        outgoing = {}
        for a, pool in agent_pool.items():
            if len(pool) == 0:
                outgoing[a] = {}
                continue
            items = list(pool.items())
            uncerts = np.array([v[1] for _, v in items])
            thresh = np.quantile(uncerts, keep_frac) if len(uncerts) > 1 else uncerts[0]
            outgoing[a] = {d: v for (d, v) in items if v[1] <= thresh}

        new_pool = {a: dict(agent_pool[a]) for a in agent_pool}
        for a in cg.nodes():
            for b in cg.neighbors(a):
                msg = outgoing[b]
                n_msgs += 1
                msg_bytes += len(msg) * 16  # +4 bytes for provenance tag vs. the non-provenance variant
                for d, (s_b, u_b, prov_b) in msg.items():
                    if d in new_pool[a]:
                        s_a, u_a, prov_a = new_pool[a][d]
                        if prov_b <= prov_a:
                            # every originating agent in this message is already
                            # accounted for in our pool -- pure relay, do not re-fuse
                            continue
                        w_a, w_b = 1.0 / u_a, 1.0 / u_b
                        fused_s = (w_a * s_a + w_b * s_b) / (w_a + w_b)
                        fused_u = 1.0 / (w_a + w_b)
                        new_pool[a][d] = (fused_s, fused_u, prov_a | prov_b)
                    else:
                        new_pool[a][d] = (s_b, u_b, prov_b)
        for a in new_pool:
            if len(new_pool[a]) > pool_cap:
                items = sorted(new_pool[a].items(), key=lambda kv: -kv[1][0])[:pool_cap]
                new_pool[a] = dict(items)
        agent_pool = new_pool

    merged = {}
    for a, pool in agent_pool.items():
        for d, (s, u, prov) in pool.items():
            if d not in merged:
                merged[d] = (s, u, prov)
            else:
                s_a, u_a, prov_a = merged[d]
                if prov <= prov_a:
                    continue
                w_a, w_b = 1.0 / u_a, 1.0 / u
                merged[d] = ((w_a * s_a + w_b * s) / (w_a + w_b), 1.0 / (w_a + w_b), prov_a | prov)
    ranked = sorted(merged.items(), key=lambda kv: -kv[1][0])[:k]
    top_ids = [d for d, _ in ranked]
    return dict(top_ids=top_ids, work=work_units, msgs=n_msgs, msg_bytes=msg_bytes)
